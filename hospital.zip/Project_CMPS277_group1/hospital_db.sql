-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 10, 2020 at 06:32 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--
CREATE DATABASE IF NOT EXISTS `hospital` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hospital`;

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE IF NOT EXISTS `appointment` (
  `doctor_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `type` text NOT NULL,
  `appointment_date` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  PRIMARY KEY (`doctor_id`,`appointment_date`),
  KEY `patient_id` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT DELAYED IGNORE INTO `appointment` (`doctor_id`, `patient_id`, `type`, `appointment_date`) VALUES
(423, 4536432, 'check up', '2018-09-22 00:00:00'),
(423, 2132312, 'check up', '2020-05-09 00:00:00'),
(423, 4326565, 'operation', '2020-11-12 00:00:00'),
(423, 4568878, 'check up', '2020-11-13 00:00:00'),
(423, 8123133, 'check up', '2020-11-14 00:00:00'),
(423, 8323289, 'operation', '2020-11-15 00:00:00'),
(423, 8793832, 'operation', '2020-11-16 00:00:00'),
(423, 8794233, 'check up', '2020-11-17 00:00:00'),
(423, 4567778, 'operation', '2020-12-12 00:00:00'),
(432, 8787212, 'operation', '2020-06-22 12:00:00'),
(432, 1321232, 'check up', '2020-11-18 00:00:00'),
(432, 8122122, 'check up', '2020-11-19 00:00:00'),
(432, 8281891, 'operation', '2020-11-20 00:00:00'),
(432, 8322312, 'operation', '2020-11-21 00:00:00'),
(459, 2112311, 'check up', '2020-06-03 00:00:00'),
(459, 4343232, 'operation', '2020-06-04 00:00:00'),
(567, 4453778, 'Check up', '2020-05-10 13:00:00'),
(567, 4453778, 'Operation', '2020-05-10 13:09:00'),
(567, 8123132, 'operation', '2020-11-14 10:00:00'),
(567, 4453778, 'operation', '2020-11-23 00:00:00'),
(679, 8777221, 'check up', '2007-12-12 03:00:00'),
(679, 3217778, 'check up', '2020-11-12 01:00:00'),
(679, 7687521, 'operation', '2020-11-12 02:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `bloodunit`
--

DROP TABLE IF EXISTS `bloodunit`;
CREATE TABLE IF NOT EXISTS `bloodunit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(3) NOT NULL,
  `amount` int(11) NOT NULL,
  `hospId` int(11) NOT NULL DEFAULT '9021',
  PRIMARY KEY (`id`,`hospId`),
  UNIQUE KEY `type` (`type`),
  KEY `bloodunit_ibfk_1` (`hospId`)
) ENGINE=InnoDB AUTO_INCREMENT=1244 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodunit`
--

INSERT DELAYED IGNORE INTO `bloodunit` (`id`, `type`, `amount`, `hospId`) VALUES
(1234, 'A+', 101, 9021),
(1235, 'A-', 108, 9021),
(1237, 'B-', 124, 9021),
(1238, 'O+', 88, 9021),
(1239, 'O-', 68, 9021),
(1240, 'AB+', 130, 9021),
(1241, 'AB-', 118, 9021),
(1243, 'B+', 200, 9021);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `Deptname` varchar(50) NOT NULL,
  PRIMARY KEY (`Deptname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT DELAYED IGNORE INTO `department` (`Deptname`) VALUES
('Cardiology'),
('Dermatology'),
('Emergency'),
('Neurology'),
('Oncology'),
('Physical Therapy'),
('staff');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE IF NOT EXISTS `doctor` (
  `doctor_id` int(11) NOT NULL AUTO_INCREMENT,
  `ssn` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `office` varchar(10) NOT NULL,
  `extension` int(11) NOT NULL,
  `shift` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `experience` text NOT NULL,
  PRIMARY KEY (`doctor_id`),
  UNIQUE KEY `doctor_id` (`doctor_id`,`ssn`,`hospital_id`),
  UNIQUE KEY `doctor_id_2` (`doctor_id`,`ssn`,`hospital_id`),
  UNIQUE KEY `ssn_2` (`ssn`),
  UNIQUE KEY `extension` (`extension`),
  UNIQUE KEY `office` (`office`),
  KEY `ssn` (`ssn`),
  KEY `doctor_ibfk_2` (`hospital_id`)
) ENGINE=InnoDB AUTO_INCREMENT=985 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT DELAYED IGNORE INTO `doctor` (`doctor_id`, `ssn`, `hospital_id`, `office`, `extension`, `shift`, `state`, `experience`) VALUES
(423, 732181, 321132, '67', 346, 'day', 'not available', '22 years'),
(432, 313281, 331231, '26', 521, 'night', 'unavailable', '13 years'),
(459, 999181, 332122, '98', 678, 'day', 'available', '18 years'),
(567, 323281, 987893, '27', 522, 'night', 'Available', '3 years'),
(679, 232181, 323212, '40', 679, 'day', 'available', '10 years'),
(984, 8484834, 987894, 'room122', 2020, 'day', 'available', 'Very well experienced');

-- --------------------------------------------------------

--
-- Stand-in structure for view `doctor_appointments_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `doctor_appointments_details`;
CREATE TABLE IF NOT EXISTS `doctor_appointments_details` (
`ssn` int(11)
,`patient_id` int(11)
,`appointment_date` datetime
,`type` text
,`phone_number` int(11)
,`first_name` varchar(20)
,`last_name` varchar(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_patient`
--

DROP TABLE IF EXISTS `doctor_patient`;
CREATE TABLE IF NOT EXISTS `doctor_patient` (
  `doctor_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  PRIMARY KEY (`doctor_id`,`patient_id`),
  KEY `patient_id` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_patient`
--

INSERT DELAYED IGNORE INTO `doctor_patient` (`doctor_id`, `patient_id`) VALUES
(679, 1234567),
(432, 1321232),
(459, 2112311),
(423, 2132312),
(459, 2421278),
(679, 3217778),
(423, 4326565),
(459, 4343232),
(567, 4453778),
(423, 4536432),
(423, 4567778),
(423, 4568878),
(679, 7687521),
(432, 8122122),
(567, 8123132),
(423, 8123133),
(432, 8281891),
(432, 8322312),
(423, 8323289),
(679, 8777221),
(432, 8787212),
(459, 8794233);

-- --------------------------------------------------------

--
-- Stand-in structure for view `doctor_patient_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `doctor_patient_details`;
CREATE TABLE IF NOT EXISTS `doctor_patient_details` (
`ssn` int(11)
,`doctor_id` int(11)
,`patient_id` int(11)
,`first_name` varchar(20)
,`last_name` varchar(15)
,`hospital_reg#` int(11)
,`phone_number` int(11)
,`gender` varchar(6)
,`patient_casetype` varchar(20)
,`patient_room` int(11)
,`patient_medical_record` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `doctor_tests_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `doctor_tests_details`;
CREATE TABLE IF NOT EXISTS `doctor_tests_details` (
`ssn` int(11)
,`test_id` int(11)
,`doctor_id` int(11)
,`patient_id` int(11)
,`drfn` varchar(20)
,`drln` varchar(15)
,`date_done` datetime
,`result_date` datetime
,`name` varchar(45)
);

-- --------------------------------------------------------

--
-- Table structure for table `emergeny_contact`
--

DROP TABLE IF EXISTS `emergeny_contact`;
CREATE TABLE IF NOT EXISTS `emergeny_contact` (
  `ssn` int(11) NOT NULL,
  `contact` varchar(30) NOT NULL,
  PRIMARY KEY (`ssn`,`contact`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emergeny_contact`
--

INSERT DELAYED IGNORE INTO `emergeny_contact` (`ssn`, `contact`) VALUES
(123421, '3908732'),
(222234, '3442354'),
(234242, '3098908'),
(403032, '3848484'),
(412121, '3439994'),
(412312, '312344'),
(413221, '3423254'),
(422229, '3400909'),
(431239, '3939392'),
(456787, '3838382'),
(457482, '3212154'),
(467549, '3432131'),
(472119, '3741222'),
(472222, '3472222'),
(473402, '3321232'),
(473669, '3453213'),
(477289, '3456654'),
(477289, '3489654'),
(489420, '3342654'),
(678798, '3431212'),
(723828, '3451231'),
(987324, '3020203'),
(987785, '3949598'),
(4743229, '3473737'),
(8484832, '3048832');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `hospital_id` int(11) NOT NULL AUTO_INCREMENT,
  `ssn` int(11) NOT NULL,
  `bank_account` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  `email` varchar(20) NOT NULL,
  `study_degree` varchar(45) NOT NULL,
  PRIMARY KEY (`hospital_id`),
  UNIQUE KEY `ssn_2` (`ssn`),
  KEY `ssn` (`ssn`)
) ENGINE=InnoDB AUTO_INCREMENT=987897 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT DELAYED IGNORE INTO `employee` (`hospital_id`, `ssn`, `bank_account`, `location`, `email`, `study_degree`) VALUES
(122443, 973783, 'm311bb', 'Hamra Street', 'mb31@mail.com', 'nurse graduate'),
(321132, 732181, 'b042h', 'Achrafieh', 'ba02', 'phd in cardiology'),
(321219, 342323, 'm391b', 'Bliss', 'mb00', 'nurse graduate'),
(323212, 232181, 'm032b', 'Bliss', 'mb22', 'phd in oncology'),
(331231, 313281, 's232l', 'Verdun', 'sl21', 'phd in dermatology'),
(332122, 999181, 'a242m', 'Damour', 'am32', 'Medicine graduate'),
(621311, 332111, 'k321h', 'Chiyah', 'kh77', 'nurse graduate'),
(673132, 989021, 'c889a', 'Badaro', 'ck897', 'nurse graduate'),
(673212, 332421, 'd789z', 'Badaro', 'dz90', 'nurse graduate'),
(688767, 312321, 'l891h', 'Verdun', 'lh21', 'nurse graduate'),
(839079, 872139, 'n322d', 'bliss', 'nd90', 'none'),
(893288, 831216, 'r356h', 'jnah', 'rh90', 'none'),
(899878, 877876, 'a322f', 'bliss', 'af90', 'none'),
(987893, 323281, 's232n', 'Achrafieh', 'ss1', 'phd in neurology'),
(987894, 8484834, '12sqa', 'Lebanon', 'aaa190@mail.aub.edu', 'Dermatologist'),
(987896, 8484836, 'x123v', 'Hamra Street', 'baa54@mail.aub.edu', 'nursing');

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
CREATE TABLE IF NOT EXISTS `equipment` (
  `room_extension` int(11) NOT NULL,
  `equipment` varchar(45) NOT NULL,
  PRIMARY KEY (`room_extension`,`equipment`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipment`
--

INSERT DELAYED IGNORE INTO `equipment` (`room_extension`, `equipment`) VALUES
(312, 'fully equiped'),
(313, 'not fully equiped'),
(314, 'not fully equiped'),
(315, 'fully equiped'),
(316, 'fully equiped'),
(317, 'fully equiped'),
(318, 'fully equiped'),
(319, 'fully equiped'),
(320, 'fully equiped'),
(321, 'not fully equiped'),
(322, 'not fully equiped'),
(323, 'fully equiped'),
(324, 'fully equiped'),
(325, 'fully equiped'),
(326, 'fully equiped'),
(327, 'not fully equiped'),
(328, 'fully equiped'),
(329, 'fully equiped'),
(330, 'fully equiped'),
(331, 'not fully equiped'),
(332, 'fully equiped'),
(333, 'fully equiped'),
(334, 'fully equiped'),
(335, 'fully equiped'),
(336, 'not fully equiped');

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
CREATE TABLE IF NOT EXISTS `holidays` (
  `staff_id` int(11) NOT NULL,
  `holiday` varchar(100) NOT NULL,
  PRIMARY KEY (`staff_id`,`holiday`),
  UNIQUE KEY `ssn` (`staff_id`,`holiday`),
  UNIQUE KEY `ssn_2` (`staff_id`,`holiday`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `holidays`
--

INSERT DELAYED IGNORE INTO `holidays` (`staff_id`, `holiday`) VALUES
(34, '2weeks'),
(774, '3weeks'),
(774, '6 weeks'),
(894, '4weeks');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

DROP TABLE IF EXISTS `hospital`;
CREATE TABLE IF NOT EXISTS `hospital` (
  `location` varchar(100) NOT NULL,
  `phonenumber` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `Registrationnumber` int(11) NOT NULL,
  `manager` varchar(25) NOT NULL,
  PRIMARY KEY (`Registrationnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital`
--

INSERT DELAYED IGNORE INTO `hospital` (`location`, `phonenumber`, `name`, `Registrationnumber`, `manager`) VALUES
('Hamra', 1374683, 'Hamra Hospital', 9021, 'Fadi Salameh');

-- --------------------------------------------------------

--
-- Table structure for table `medications`
--

DROP TABLE IF EXISTS `medications`;
CREATE TABLE IF NOT EXISTS `medications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_2` (`name`,`description`),
  UNIQUE KEY `name_3` (`name`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medications`
--

INSERT DELAYED IGNORE INTO `medications` (`id`, `name`, `description`) VALUES
(1, 'Amlodipine', 'treats high blood pressuree'),
(2, 'Amoxicilin', 'treats all infections'),
(11, 'Aspirin', 'Aspirin is used to reduce fever and relieve mild to moderate pain from conditions such as muscle aches, toothaches, common cold, and headaches.'),
(3, 'Atorvastatin', 'treats high cholesterol'),
(4, 'Codeine', 'treats severe pain.'),
(5, 'Cyclobenzaprine', 'treats neurological disorders'),
(6, 'Ibuprofen', 'treats back pain'),
(7, 'Lisinopril', 'treats very high blood pressure'),
(8, 'Metoprolol', 'prevents heart failure'),
(10, 'Xanax', 'treats panic and anxiety disorders');

-- --------------------------------------------------------

--
-- Table structure for table `medication_taken`
--

DROP TABLE IF EXISTS `medication_taken`;
CREATE TABLE IF NOT EXISTS `medication_taken` (
  `name` varchar(45) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`,`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `patient id` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medication_taken`
--

INSERT DELAYED IGNORE INTO `medication_taken` (`name`, `patient_id`, `doctor_id`) VALUES
('Amlodipine', 8793832, 423),
('Atorvastatin', 4567778, 423),
('Cyclobenzaprine', 1234567, 423),
('Lisinopril', 8323289, 423),
('Metoprolol', 8793832, 423),
('Codeine', 24131232, 432),
('Amlodipine', 4453778, 567),
('Amlodipine', 8123132, 567),
('Aspirin', 4453778, 567),
('Ibuprofen', 8324232, 567),
('Lisinopril', 4453778, 567),
('Xanax', 4453778, 567),
('Xanax', 8123132, 567),
('Amoxicilin', 7687521, 679);

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

DROP TABLE IF EXISTS `nurse`;
CREATE TABLE IF NOT EXISTS `nurse` (
  `nurse_id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `ssn` int(11) NOT NULL,
  `shifts` varchar(100) NOT NULL,
  `floor` varchar(10) NOT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`nurse_id`),
  KEY `supervisor_id` (`supervisor_id`),
  KEY `hospital_id` (`hospital_id`),
  KEY `ssn` (`ssn`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nurse`
--

INSERT DELAYED IGNORE INTO `nurse` (`nurse_id`, `hospital_id`, `ssn`, `shifts`, `floor`, `supervisor_id`) VALUES
(11, 688767, 312321, 'day', '3', NULL),
(12, 321219, 342323, 'day', '5', 31),
(13, 122443, 973783, 'night', '1', 12),
(19, 673212, 332421, 'day', '4', 12),
(22, 621311, 332111, 'night', '2', NULL),
(31, 673132, 989021, 'night', '4', 11),
(32, 987896, 8484836, 'Night ', '8', 19);

-- --------------------------------------------------------

--
-- Stand-in structure for view `nurse_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `nurse_details`;
CREATE TABLE IF NOT EXISTS `nurse_details` (
`nurse_id` int(11)
,`hospital_id` int(11)
,`ssn` int(11)
,`shifts` varchar(100)
,`floor` varchar(10)
,`supervisor_id` int(11)
,`lfirstname` varchar(20)
,`llastname` varchar(15)
,`department` varchar(30)
,`gender` varchar(6)
,`phonenumber` int(11)
,`bankaccount` varchar(45)
,`location` varchar(45)
,`email` varchar(20)
,`study_degree` varchar(45)
);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `ssn` int(11) NOT NULL,
  `patient_casetype` varchar(20) NOT NULL,
  `patient_medical_record` varchar(100) DEFAULT NULL,
  `patient_room` int(11) NOT NULL,
  PRIMARY KEY (`patient_id`),
  UNIQUE KEY `patient_id` (`patient_id`,`ssn`),
  UNIQUE KEY `ssn_2` (`ssn`),
  KEY `ssn` (`ssn`),
  KEY `patient_room` (`patient_room`)
) ENGINE=InnoDB AUTO_INCREMENT=24131234 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT DELAYED IGNORE INTO `patient` (`patient_id`, `ssn`, `patient_casetype`, `patient_medical_record`, `patient_room`) VALUES
(1234567, 231131, 'Brain tumor stage I', 'available', 318),
(1321232, 431239, 'undefined', 'available', 335),
(2112311, 467549, 'broken nose', 'unavailable', 324),
(2132312, 472119, 'heart disease', 'available', 332),
(2421278, 987324, 'Broken arm', 'unavailable', 320),
(3217778, 987785, 'Brain tumor', 'available', 326),
(4326565, 403032, 'heart disease', 'available', 335),
(4343232, 457482, 'Broken leg', 'unavailable', 312),
(4453778, 123421, 'Neuro disorder', 'unavailable', 322),
(4536432, 473402, 'heart disease', 'available', 312),
(4567778, 477289, 'heart disease', 'available', 317),
(4568878, 489420, 'heart attack', 'unavailable', 323),
(7687521, 412121, 'Breast cancer', 'available', 313),
(8122122, 4743229, 'hand burn', 'available', 315),
(8123132, 412312, 'Neuro disorder', 'available', 330),
(8123133, 472222, 'heart attack', 'available', 329),
(8281891, 678798, 'Back burn', 'available', 314),
(8322312, 8484832, 'hand burn', 'available', 331),
(8323289, 413221, 'heart attack', 'available', 327),
(8324232, 456787, 'Back pain', 'available', 333),
(8777221, 422229, 'Brain tumor', 'available', 334),
(8787212, 234242, 'hand burn', 'available', 331),
(8793832, 222234, 'heart failure', 'available', 317),
(8794233, 723828, 'heart disease', 'available', 327),
(24131232, 473669, 'ankle pain', 'available', 323),
(24131233, 8484833, 'Broken Hand', 'Good medical record', 314);

-- --------------------------------------------------------

--
-- Stand-in structure for view `patient_appointments_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `patient_appointments_details`;
CREATE TABLE IF NOT EXISTS `patient_appointments_details` (
`ssn` int(11)
,`doctor_id` int(11)
,`patient_id` int(11)
,`appointment_date` datetime
,`type` text
,`extension` int(11)
,`office` varchar(10)
,`first_name` varchar(20)
,`last_name` varchar(15)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `patient_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `patient_details`;
CREATE TABLE IF NOT EXISTS `patient_details` (
`ssn` int(11)
,`patient_id` int(11)
,`hospital_reg#` int(11)
,`phone_number` int(11)
,`f` varchar(20)
,`l` varchar(15)
,`middle_name` varchar(20)
,`gender` varchar(6)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `patient_medications_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `patient_medications_details`;
CREATE TABLE IF NOT EXISTS `patient_medications_details` (
`patient_id` int(11)
,`ssn` int(11)
,`name` varchar(45)
,`description` varchar(150)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `patient_test_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `patient_test_details`;
CREATE TABLE IF NOT EXISTS `patient_test_details` (
`ssn` int(11)
,`drfn` varchar(20)
,`drln` varchar(15)
,`date_done` datetime
,`result_date` datetime
,`name` varchar(45)
);

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
CREATE TABLE IF NOT EXISTS `people` (
  `ssn` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_reg#` int(11) NOT NULL DEFAULT '9021',
  `phone_number` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `middle_name` varchar(20) NOT NULL,
  `last_name` varchar(15) DEFAULT NULL,
  `gender` varchar(6) NOT NULL,
  `dep_name` varchar(30) DEFAULT NULL,
  `type` enum('Doctor','Patient','Nurse','Staff') NOT NULL DEFAULT 'Patient',
  PRIMARY KEY (`ssn`),
  KEY `hospital_reg#` (`hospital_reg#`),
  KEY `dep_name` (`dep_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8484837 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `people`
--

INSERT DELAYED IGNORE INTO `people` (`ssn`, `hospital_reg#`, `phone_number`, `first_name`, `middle_name`, `last_name`, `gender`, `dep_name`, `type`) VALUES
(123421, 9021, 3131112, 'Joseph', 'Antoinee', 'Boustany', 'Male', 'Neurology', 'Patient'),
(222234, 9021, 3456783, 'Marco', 'joe', 'Noujaim', 'Male', 'Cardiology', 'Patient'),
(231131, 9021, 3123133, 'Melanie', 'joe', 'Azzi', 'Female', 'Oncology', 'Patient'),
(232181, 9021, 3432393, 'Mahdi', '', 'Bazzi', 'Male', 'Oncology', 'Doctor'),
(234242, 9021, 3345033, 'Jean', '', 'Osta', 'Male', 'Dermatology', 'Patient'),
(312321, 9021, 3458481, 'Lea', '', 'Haddad', 'Female', 'Cardiology', 'Nurse'),
(313281, 9021, 3334232, 'Samia', '', 'Lteif', 'Female', 'Dermatology', 'Doctor'),
(323281, 9021, 3534593, 'Stephany', '', 'Nasr', 'Female', 'Neurology', 'Doctor'),
(324281, 9021, 3543293, 'Nada', '', 'Salman', 'Female', 'Physical Therapy', 'Patient'),
(332111, 9021, 3431281, 'Kamil', '', 'Hachem', 'Male', 'Emergency', 'Nurse'),
(332421, 9021, 3424131, 'Dania', '', 'Zreik', 'Female', 'Neurology', 'Nurse'),
(342323, 9021, 3414324, 'Michelle', '', 'Botros', 'Female', 'Oncology', 'Nurse'),
(403032, 9021, 3838832, 'Mohamad', '', 'Ahmad', 'Male', 'Cardiology', 'Patient'),
(412121, 9021, 3121212, 'Johnny', '', 'Haidar', 'Male', 'Oncology', 'Patient'),
(412312, 9021, 3213211, 'Nawal', 'Maria', 'Dib', 'Female', 'Neurology', 'Patient'),
(413221, 9021, 3722323, 'Christina', '', 'Chamoun', 'Female', 'Cardiology', 'Patient'),
(422229, 9021, 3734532, 'Joe', '', 'Dargham', 'Male', 'Oncology', 'Patient'),
(431239, 9021, 3721313, 'Carole', '', 'Lagger', 'Female', 'Dermatology', 'Patient'),
(456787, 9021, 3993873, 'Anthony', '', 'Chaaban', 'Male', 'Physical Therapy', 'Patient'),
(457482, 9021, 3087181, 'Fatima', '', 'Malka', 'Female', 'Emergency', 'Patient'),
(467549, 9021, 3998786, 'Elie', '', 'Berbari', 'Male', 'Emergency', 'Patient'),
(472119, 9021, 3741222, 'Jessica', '', 'Rabah', 'Female', 'Cardiology', 'Patient'),
(472222, 9021, 3783444, 'Sacha', '', 'Tawk', 'Female', 'Cardiology', 'Patient'),
(473289, 9021, 3789423, 'John', '', 'Kassab', 'Male', 'Cardiology', 'Patient'),
(473402, 9021, 3757823, 'Anthony', '', 'Fakhry', 'Male', 'Cardiology', 'Patient'),
(473669, 9021, 3789423, 'Mohamad', '', 'Husseini', 'Male', 'Physical Therapy', 'Patient'),
(477289, 9021, 3789423, 'John', 'Phil', 'Kassab', 'Male', 'Cardiology', 'Patient'),
(489420, 9021, 3239425, 'Ali', '', 'Zein', 'Male', 'Cardiology', 'Patient'),
(678798, 9021, 3097689, 'Karla', 'El', 'Rizk', 'Female', 'Dermatology', 'Patient'),
(723828, 9021, 3232333, 'Hussein', '', 'Bayram', 'Male', 'Cardiology', 'Patient'),
(732181, 9021, 3544893, 'Bilal', '', 'Ahmad', 'Male', 'Cardiology', 'Doctor'),
(831216, 9021, 3532343, 'roger', '', 'haddad', 'male', 'staff', 'Staff'),
(872139, 9021, 3032423, 'Nohad', '', 'Deek', 'female', 'staff', 'Staff'),
(877876, 9021, 3548093, 'Ali', '', 'Fares', 'male', 'staff', 'Staff'),
(973783, 9021, 3432329, 'Michel', '', 'Baaklini', 'Male', 'Dermatology', 'Nurse'),
(987324, 9021, 3329293, 'Nour', '', 'Baydoun', 'Female', 'Emergency', 'Patient'),
(987785, 9021, 3897624, 'Maria', 'Jose', 'Daoud', 'Female', 'Oncology', 'Patient'),
(989021, 9021, 3873212, 'Celine', '', 'Akl', 'Female', 'Physical therapy', 'Nurse'),
(999181, 9021, 3989870, 'Alain', '', 'Malek', 'Male', 'Emergency', 'Doctor'),
(4743229, 9021, 3343423, 'Rami', '', 'Khoury', 'Male', 'Dermatology', 'Patient'),
(8484832, 9021, 3734423, 'Ahmad', '', 'Rabah', 'Male', 'Cardiology', 'Patient'),
(8484833, 9021, 70711072, 'Abed', 'Ahmad', 'Hajj', 'male', 'Emergency', 'Patient'),
(8484834, 9021, 3949496, 'Hadi', '', 'Dahrouj', 'male', 'Dermatology', 'Doctor'),
(8484836, 9021, 9990990, 'Maha', 'A', 'Bassil', 'female', 'Physical Therapy', 'Nurse');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
CREATE TABLE IF NOT EXISTS `room` (
  `departmen_tname` varchar(50) NOT NULL,
  `extension` int(11) NOT NULL,
  `number_of_beds` int(11) NOT NULL,
  `state` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`extension`),
  KEY `departmen_tname` (`departmen_tname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT DELAYED IGNORE INTO `room` (`departmen_tname`, `extension`, `number_of_beds`, `state`, `type`) VALUES
('dermatology', 312, 2, 'full', 'normal'),
('oncology', 313, 1, 'full', 'intensive'),
('dermatology', 314, 2, 'full', 'normal'),
('dermatology', 315, 2, 'not full', 'normal'),
('cardiology', 316, 1, 'empty', 'intensive'),
('cardiology', 317, 2, 'full', 'normal'),
('oncology', 318, 2, 'not full', 'normal'),
('neurology', 319, 1, 'empty', 'intensive'),
('emergency', 320, 2, 'not full', 'normal'),
('emergency', 321, 2, 'empty', 'normal'),
('neurology', 322, 1, 'full', 'intensive'),
('cardiology', 323, 2, 'full', 'intensive'),
('Physical therapy', 324, 2, 'not full', 'normal'),
('dermatology', 325, 2, 'empty', 'normal'),
('oncology', 326, 1, 'full', 'intensive'),
('cardiology', 327, 2, 'full', 'intensive'),
('cardiology', 328, 2, 'empty', 'normal'),
('cardiology', 329, 1, 'full', 'intensive'),
('oncology', 330, 2, 'not full', 'normal'),
('dermatology', 331, 2, 'full', 'normal'),
('cardiology', 332, 2, 'not full', 'normal'),
('emergency', 333, 2, 'not full', 'normal'),
('oncology', 334, 1, 'full', 'intensive'),
('cardiology', 335, 2, 'full', 'normal'),
('neurology', 336, 2, 'empty', 'normal');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `ssn` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `type` varchar(40) NOT NULL,
  `salary` decimal(10,0) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`staff_id`),
  UNIQUE KEY `staff_id` (`staff_id`,`ssn`,`hospital_id`),
  UNIQUE KEY `ssn_2` (`ssn`),
  KEY `ssn` (`ssn`),
  KEY `hospital_id` (`hospital_id`)
) ENGINE=InnoDB AUTO_INCREMENT=895 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT DELAYED IGNORE INTO `staff` (`staff_id`, `ssn`, `hospital_id`, `type`, `salary`, `description`) VALUES
(34, 831216, 893288, 'Chef', '2500', 'prepare meals to serve patients and doctorss'),
(774, 872139, 839079, 'parking', '2000', 'help employees and patients park their cars'),
(894, 877876, 899878, 'cleaning', '2000', 'washing clothes,vaccuming');

-- --------------------------------------------------------

--
-- Stand-in structure for view `staff_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `staff_details`;
CREATE TABLE IF NOT EXISTS `staff_details` (
`staff_id` int(11)
,`ssn` int(11)
,`salary` decimal(10,0)
,`description` text
,`type` varchar(40)
,`lfirstname` varchar(20)
,`llastname` varchar(15)
,`bankaccount` varchar(45)
,`location` varchar(45)
,`email` varchar(20)
,`study_degree` varchar(45)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supervisor_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `supervisor_details`;
CREATE TABLE IF NOT EXISTS `supervisor_details` (
`first_name` varchar(20)
,`last_name` varchar(15)
,`nurse_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
CREATE TABLE IF NOT EXISTS `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT DELAYED IGNORE INTO `test` (`id`, `name`) VALUES
(3, 'blood test version 1'),
(1, 'blood test version 2'),
(5, 'blood testt'),
(8, 'bones test'),
(13, 'Brain Test'),
(6, 'cardiac stress test'),
(9, 'endoscopy'),
(7, 'endoscopy v1'),
(12, 'genetic test'),
(2, 'skin allergy test.'),
(11, 'X-ray');

-- --------------------------------------------------------

--
-- Table structure for table `test_done`
--

DROP TABLE IF EXISTS `test_done`;
CREATE TABLE IF NOT EXISTS `test_done` (
  `test_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `date_done` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `result_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`test_id`,`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `patient_id` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_done`
--

INSERT DELAYED IGNORE INTO `test_done` (`test_id`, `patient_id`, `doctor_id`, `date_done`, `result_date`) VALUES
(1, 1234567, 423, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(2, 1321232, 432, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(3, 2112311, 459, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(5, 2421278, 679, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(5, 3217778, 567, '2020-05-10 05:50:09', '2020-11-10 02:00:00'),
(5, 4453778, 567, '2020-05-10 18:45:25', '2020-05-10 02:00:00'),
(6, 4326565, 423, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(7, 3217778, 567, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(8, 8324232, 679, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(9, 7687521, 567, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(11, 24131232, 679, '2020-05-06 03:03:15', '2020-05-09 00:00:00'),
(12, 8123132, 567, '2020-05-06 03:03:15', '2020-05-09 00:00:00');

-- --------------------------------------------------------

--
-- Structure for view `doctor_appointments_details`
--
DROP TABLE IF EXISTS `doctor_appointments_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `doctor_appointments_details`  AS  select `dodo`.`ssn` AS `ssn`,`popo`.`patient_id` AS `patient_id`,`aa`.`appointment_date` AS `appointment_date`,`aa`.`type` AS `type`,`p1`.`phone_number` AS `phone_number`,`p1`.`first_name` AS `first_name`,`p1`.`last_name` AS `last_name` from ((((`appointment` `aa` join `people` `p1`) join `people` `p2`) join `patient` `popo`) join `doctor` `dodo`) where ((`aa`.`patient_id` = `popo`.`patient_id`) and (`p1`.`ssn` = `popo`.`ssn`) and (`p2`.`ssn` = `dodo`.`ssn`) and (`dodo`.`doctor_id` = `aa`.`doctor_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `doctor_patient_details`
--
DROP TABLE IF EXISTS `doctor_patient_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `doctor_patient_details`  AS  select `doctor`.`ssn` AS `ssn`,`ppp`.`doctor_id` AS `doctor_id`,`thep`.`patient_id` AS `patient_id`,`p1`.`first_name` AS `first_name`,`p1`.`last_name` AS `last_name`,`p1`.`hospital_reg#` AS `hospital_reg#`,`p1`.`phone_number` AS `phone_number`,`p1`.`gender` AS `gender`,`thep`.`patient_casetype` AS `patient_casetype`,`thep`.`patient_room` AS `patient_room`,`thep`.`patient_medical_record` AS `patient_medical_record` from ((((`people` `p2` join `doctor`) join `doctor_patient` `ppp`) join `patient` `thep`) join `people` `p1`) where ((`ppp`.`doctor_id` = `doctor`.`doctor_id`) and (`doctor`.`ssn` = `p2`.`ssn`) and (`ppp`.`patient_id` = `thep`.`patient_id`) and (`thep`.`ssn` = `p1`.`ssn`)) ;

-- --------------------------------------------------------

--
-- Structure for view `doctor_tests_details`
--
DROP TABLE IF EXISTS `doctor_tests_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `doctor_tests_details`  AS  select `dod`.`ssn` AS `ssn`,`test_done`.`test_id` AS `test_id`,`dod`.`doctor_id` AS `doctor_id`,`pop`.`patient_id` AS `patient_id`,`p1`.`first_name` AS `drfn`,`p1`.`last_name` AS `drln`,`test_done`.`date_done` AS `date_done`,`test_done`.`result_date` AS `result_date`,`test`.`name` AS `name` from (((((`people` `p1` join `people` `p2`) join `patient` `pop`) join `doctor` `dod`) join `test_done`) join `test`) where ((`pop`.`ssn` = `p1`.`ssn`) and (`p2`.`ssn` = `dod`.`ssn`) and (`test_done`.`doctor_id` = `dod`.`doctor_id`) and (`test_done`.`test_id` = `test`.`id`) and (`test_done`.`patient_id` = `pop`.`patient_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `nurse_details`
--
DROP TABLE IF EXISTS `nurse_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `nurse_details`  AS  select `n`.`nurse_id` AS `nurse_id`,`n`.`hospital_id` AS `hospital_id`,`n`.`ssn` AS `ssn`,`n`.`shifts` AS `shifts`,`n`.`floor` AS `floor`,`n`.`supervisor_id` AS `supervisor_id`,`l`.`first_name` AS `lfirstname`,`l`.`last_name` AS `llastname`,`l`.`dep_name` AS `department`,`l`.`gender` AS `gender`,`l`.`phone_number` AS `phonenumber`,`e`.`bank_account` AS `bankaccount`,`e`.`location` AS `location`,`e`.`email` AS `email`,`e`.`study_degree` AS `study_degree` from ((`nurse` `n` join `people` `l`) join `employee` `e`) where ((`n`.`ssn` = `l`.`ssn`) and (`e`.`ssn` = `l`.`ssn`) and (`n`.`ssn` = `l`.`ssn`)) ;

-- --------------------------------------------------------

--
-- Structure for view `patient_appointments_details`
--
DROP TABLE IF EXISTS `patient_appointments_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patient_appointments_details`  AS  select `popo`.`ssn` AS `ssn`,`dodo`.`doctor_id` AS `doctor_id`,`popo`.`patient_id` AS `patient_id`,`aa`.`appointment_date` AS `appointment_date`,`aa`.`type` AS `type`,`dodo`.`extension` AS `extension`,`dodo`.`office` AS `office`,`p2`.`first_name` AS `first_name`,`p2`.`last_name` AS `last_name` from ((((`appointment` `aa` join `people` `p1`) join `people` `p2`) join `patient` `popo`) join `doctor` `dodo`) where ((`aa`.`patient_id` = `popo`.`patient_id`) and (`p1`.`ssn` = `popo`.`ssn`) and (`p2`.`ssn` = `dodo`.`ssn`) and (`dodo`.`doctor_id` = `aa`.`doctor_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `patient_details`
--
DROP TABLE IF EXISTS `patient_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patient_details`  AS  select `thep`.`ssn` AS `ssn`,`thep`.`patient_id` AS `patient_id`,`p1`.`hospital_reg#` AS `hospital_reg#`,`p1`.`phone_number` AS `phone_number`,`p1`.`first_name` AS `f`,`p1`.`last_name` AS `l`,`p1`.`middle_name` AS `middle_name`,`p1`.`gender` AS `gender` from (`people` `p1` join `patient` `thep`) where (`thep`.`ssn` = `p1`.`ssn`) ;

-- --------------------------------------------------------

--
-- Structure for view `patient_medications_details`
--
DROP TABLE IF EXISTS `patient_medications_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patient_medications_details`  AS  select `patient`.`patient_id` AS `patient_id`,`patient`.`ssn` AS `ssn`,`medications`.`name` AS `name`,`medications`.`description` AS `description` from (((`people` join `patient`) join `medication_taken`) join `medications`) where ((`patient`.`ssn` = `people`.`ssn`) and (`medication_taken`.`patient_id` = `patient`.`patient_id`) and (`medications`.`name` = `medication_taken`.`name`)) ;

-- --------------------------------------------------------

--
-- Structure for view `patient_test_details`
--
DROP TABLE IF EXISTS `patient_test_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patient_test_details`  AS  select `patient`.`ssn` AS `ssn`,`p2`.`first_name` AS `drfn`,`p2`.`last_name` AS `drln`,`test_done`.`date_done` AS `date_done`,`test_done`.`result_date` AS `result_date`,`test`.`name` AS `name` from (((((`people` `p1` join `people` `p2`) join `patient`) join `doctor`) join `test_done`) join `test`) where ((`patient`.`ssn` = `p1`.`ssn`) and (`p2`.`ssn` = `doctor`.`ssn`) and (`test_done`.`doctor_id` = `doctor`.`doctor_id`) and (`test_done`.`test_id` = `test`.`id`) and (`test_done`.`patient_id` = `patient`.`patient_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `staff_details`
--
DROP TABLE IF EXISTS `staff_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `staff_details`  AS  select `s`.`staff_id` AS `staff_id`,`s`.`ssn` AS `ssn`,`s`.`salary` AS `salary`,`s`.`description` AS `description`,`s`.`type` AS `type`,`l`.`first_name` AS `lfirstname`,`l`.`last_name` AS `llastname`,`e`.`bank_account` AS `bankaccount`,`e`.`location` AS `location`,`e`.`email` AS `email`,`e`.`study_degree` AS `study_degree` from ((`staff` `s` join `people` `l`) join `employee` `e`) where ((`s`.`ssn` = `l`.`ssn`) and (`e`.`ssn` = `l`.`ssn`) and (`s`.`ssn` = `l`.`ssn`)) ;

-- --------------------------------------------------------

--
-- Structure for view `supervisor_details`
--
DROP TABLE IF EXISTS `supervisor_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `supervisor_details`  AS  select `ps`.`first_name` AS `first_name`,`ps`.`last_name` AS `last_name`,`n`.`nurse_id` AS `nurse_id` from (((`nurse` `n` join `nurse` `ns`) join `people` `pn`) join `people` `ps`) where ((`pn`.`ssn` = `n`.`ssn`) and (`ps`.`ssn` = `ns`.`ssn`) and (`n`.`supervisor_id` = `ns`.`nurse_id`)) ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bloodunit`
--
ALTER TABLE `bloodunit`
  ADD CONSTRAINT `bloodunit_ibfk_1` FOREIGN KEY (`hospId`) REFERENCES `hospital` (`Registrationnumber`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor`
--
ALTER TABLE `doctor`
  ADD CONSTRAINT `doctor_ibfk_1` FOREIGN KEY (`ssn`) REFERENCES `people` (`ssn`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doctor_ibfk_2` FOREIGN KEY (`hospital_id`) REFERENCES `employee` (`hospital_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor_patient`
--
ALTER TABLE `doctor_patient`
  ADD CONSTRAINT `doctor_patient_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doctor_patient_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `emergeny_contact`
--
ALTER TABLE `emergeny_contact`
  ADD CONSTRAINT `emergeny_contact_ibfk_1` FOREIGN KEY (`ssn`) REFERENCES `people` (`ssn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`ssn`) REFERENCES `people` (`ssn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `equipment`
--
ALTER TABLE `equipment`
  ADD CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`room_extension`) REFERENCES `room` (`extension`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `holidays`
--
ALTER TABLE `holidays`
  ADD CONSTRAINT `holidays_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `medication_taken`
--
ALTER TABLE `medication_taken`
  ADD CONSTRAINT `medication_taken_ibfk_1` FOREIGN KEY (`name`) REFERENCES `medications` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `medication_taken_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `medication_taken_ibfk_3` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nurse`
--
ALTER TABLE `nurse`
  ADD CONSTRAINT `nurse_ibfk_2` FOREIGN KEY (`hospital_id`) REFERENCES `employee` (`hospital_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nurse_ibfk_3` FOREIGN KEY (`ssn`) REFERENCES `people` (`ssn`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nurse_ibfk_4` FOREIGN KEY (`supervisor_id`) REFERENCES `nurse` (`nurse_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `patient_ibfk_1` FOREIGN KEY (`ssn`) REFERENCES `people` (`ssn`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_ibfk_2` FOREIGN KEY (`patient_room`) REFERENCES `room` (`extension`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `people`
--
ALTER TABLE `people`
  ADD CONSTRAINT `people_ibfk_1` FOREIGN KEY (`hospital_reg#`) REFERENCES `hospital` (`Registrationnumber`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `people_ibfk_2` FOREIGN KEY (`dep_name`) REFERENCES `department` (`Deptname`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`departmen_tname`) REFERENCES `department` (`Deptname`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`ssn`) REFERENCES `people` (`ssn`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `staff_ibfk_2` FOREIGN KEY (`hospital_id`) REFERENCES `employee` (`hospital_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `test_done`
--
ALTER TABLE `test_done`
  ADD CONSTRAINT `test_done_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test_done_ibfk_3` FOREIGN KEY (`test_id`) REFERENCES `test` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test_done_ibfk_4` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`) ON DELETE SET NULL;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
