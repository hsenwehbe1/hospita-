The source code of the website is found in 'hospital' folder please run login.php page first

The code is written using php as a backend and html, css, javascript as frontend

The database used is in phpmyadmin of wamp server mysql port 3306

The database file is hospital_dp.sql file attached in the folder, you have to import it
 to your phpmyadmin so you can run the project.