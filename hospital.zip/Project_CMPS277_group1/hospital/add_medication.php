<?php

	require 'connect.php';

	if(isset($_POST['name']) && isset($_POST['description'])){

		$name = $_POST['name'];
		$description = $_POST['description']; 

		$stmt = $conn->prepare("INSERT INTO medications values(null,'$name','$description')");

		try{

		$stmt->execute();

		echo "<script>alert('Medication Added');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('Medication already exists');  location.replace('admin.php'); </script>";
	}

	}

?>