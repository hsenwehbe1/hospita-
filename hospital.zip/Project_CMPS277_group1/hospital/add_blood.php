<?php

	require 'connect.php';

	if(isset($_POST['type']) && isset($_POST['amount'])){

		$type = $_POST['type'];
		$amount = $_POST['amount'];

		$stmt = $conn->prepare("INSERT INTO bloodunit VALUES (NULL, '$type', $amount, DEFAULT)");
		try{

		$stmt->execute();

		echo "<script>alert('BLood Unit Added');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('Blood Unit already exists');  location.replace('admin.php'); </script>";
	}
	}

?>