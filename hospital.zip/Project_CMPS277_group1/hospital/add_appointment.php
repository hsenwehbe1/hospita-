<?php

	require 'connect.php';

	if(isset($_POST['doctor_id']) && isset($_POST['patient_id']) && isset($_POST['ssn']) && isset($_POST['type']) && isset($_POST['app_date']) ){

		$doctor_id = $_POST['doctor_id'];
		$patient_id = $_POST['patient_id']; 
		$ssn = $_POST['ssn'];
		$app_date = $_POST['app_date'];
		$type = $_POST['type'];



		$stmt = $conn->prepare("INSERT INTO appointment VALUES($doctor_id, $patient_id, '$type'
					, '$app_date')");

		try{

		$stmt->execute();

		echo "<script>alert(' Added');  location.replace('Doctor.php?ssn=$ssn') </script>";


	}
	catch(PDOException $e){
		echo "<script>alert(' already exists, choose another date');  window.history.back(); </script>";
	}

	}

?>