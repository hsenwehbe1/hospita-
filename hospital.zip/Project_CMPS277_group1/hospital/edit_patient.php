<?php

	require 'connect.php';

	if(isset($_POST['case']) && isset($_POST['record']) && isset($_POST['patient_id'])){

		$case = $_POST['case'];
		$record = $_POST['record'];
		$patient_id = $_POST['patient_id'];


		$stmt = $conn->prepare("SELECT patient_room from patient where patient_id = $patient_id");
		$stmt->execute();
		$old_room = $stmt->fetch()['patient_room'];

		if(isset($_POST['room'])){
			$room = $_POST['room'];
		$stmt = $conn->prepare("UPDATE patient SET patient_casetype = '$case', patient_medical_record = '$record', patient_room = '$room' where patient_id = $patient_id");
		$stmt->execute();


		$stmt = $conn->prepare("SELECT number_of_beds, state,extension from room where extension = $old_room");
		$stmt->execute();
		$old_room_data = $stmt->fetch();

		$s = "";

		if($old_room_data['state'] == 'full' && $old_room_data['number_of_beds'] == 2){
			$s = 'not full';
		}

		else if($old_room_data['state'] == 'full' && $old_room_data['number_of_beds'] == 1){
			$s = 'empty';
		}

		else if($old_room_data['state'] == 'not full'){
			$s = 'empty';
		}

		$stmt = $conn->prepare("UPDATE room set state = '$s' where extension = $old_room");
		$stmt->execute();


		$stmt = $conn->prepare("SELECT number_of_beds, state,extension from room where extension = $room");
		$stmt->execute();
		$new_room_data = $stmt->fetch();


		if($new_room_data['state'] == 'empty' && $new_room_data['number_of_beds'] == 2){
			$s = 'not full';
		}

		else if($new_room_data['state'] == 'empty' && $new_room_data['number_of_beds'] == 1){
			$s = 'full';
		}

		else if($new_room_data['state'] == 'not full'){
			$s = 'full';
		}

		$stmt = $conn->prepare("UPDATE room set state = '$s' where extension = $room");
		

		$stmt->execute();

	}

	else{
		$stmt = $conn->prepare("UPDATE patient SET patient_casetype = '$case', patient_medical_record = '$record' where patient_id = $patient_id");
		$stmt->execute();
	}

		echo "<script>alert('Patient info updated');  location.replace('admin.php'); </script>";

}
?>