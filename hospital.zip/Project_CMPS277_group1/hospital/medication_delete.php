<?php
	require 'connect.php';
	$reciever=explode("~",$_GET['q']);
	$a=$reciever[0];
	$b=$reciever[1];
	$c=$reciever[2];
	try{
		$delete_=$conn->prepare("delete from hospital.medication_taken where patient_id='$b' and doctor_id='$c' and name='$a';");
		if($delete_->execute()){
			echo "true";
		}else
		{
			echo "false";
		}
	}catch (PDOException $e){
		echo "false";
	}
?>