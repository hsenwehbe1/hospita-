<?php 
	require 'connect.php';
	$reciever=explode("~",$_GET['q']);
	$a=$reciever[0];//id
	$b=$reciever[1];//doctor
	$c=$reciever[2];//patient
	$d=$reciever[3];//d
	$e=$reciever[4];//re
	try{

	$insert=$conn->prepare("INSERT into test_done VALUES('$a','$c','$b',DEFAULT,'$e');");
	$insert->execute();     

	echo"true";
	}catch (PDOException $e){
		echo "false";
	}
?>