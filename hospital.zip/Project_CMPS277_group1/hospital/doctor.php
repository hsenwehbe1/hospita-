<!DOCTYPE html>
<html>
<head>
	
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script>
	var drp="";
	var test_dd="";
	var del_app="";
	function close_it(){
		$('#modal_1').css('display','none');
		$('#modal_2').css('display','none');
		$('#modal').css('display','none');
	}
	function insert_med(pa,dr){
		drp=pa+"~"+dr;
		console.log(drp);
		$('#modal').css('display','block');
		const ajax = new XMLHttpRequest();
					ajax.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							var resp = this.responseText;
							view_response(resp);
						}
					};
					var str=pa;
					console.log(str);
					ajax.open("GET", "med_view.php?q="+str,true);
					ajax.send();
	}
	function showt(dr){
		test_dd=dr;
		$('#modal_2').css('display','block');
	}
	function view_response(response){
				$('#show_med').html(response);
	}
	
	function delete_col(appointment,pa,doctor){
		del_app=appointment+"~"+pa+"~"+doctor;
		console.log(del_app);
		$('#modal_1').css('display','block');
	}
	function delete_test(id,pa){
		del_app=id+"~"+pa;
		console.log(del_app);
		$('#modal_1').css('display','block');
	}
		$(document).ready(function(){
			$('#unique').click(function(){//when button is clicked
				if(!$('#up_date').val().length !== 0){//empty
					const ajax = new XMLHttpRequest();
					ajax.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							var resp = this.responseText;
							handleResponse(resp);
						}
					};
					var str=$('#up_date').val()+"~"+drp;
					$('#up_date').val('');
					console.log(str);
					ajax.open("GET", "medication_insert.php?q="+str,true);
					ajax.send();
				}
			});
			$('#unique_1').click(function(){
				if(!$('#de_date').val().length !== 0){//empty
					const ajax = new XMLHttpRequest();
					ajax.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							var resp = this.responseText;
							handleResponse(resp);
						}
					};
					var str=$('#de_date').val()+"~"+drp;
					$('#de_date').val('');
					console.log(str);
					ajax.open("GET", "medication_delete.php?q="+str,true);
					ajax.send();
				}
			});
			$('#unique_2').click(function(){//empty
					const ajax = new XMLHttpRequest();
					ajax.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							var resp = this.responseText;
							handleResponse(resp);
						}
					};
					var str=del_app;
					console.log(str);
					ajax.open("GET", "delete_test_date.php?q="+str,true);
					ajax.send();
			});
			$('#unique_3').click(function(){
				if(!$('#insert_date').val().length !== 0 && $('#resultt_date').val().length !== 0 ){//empty
					const ajax = new XMLHttpRequest();
					ajax.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							var resp = this.responseText;
							handleResponse(resp);
						}
					};
					var str=$('#insert_date').val()+"~"+test_dd+"~"+$('#patientt_date').val()+"~"+$('#donee_date').val()+"~"+$('#resultt_date').val();
					$('#insert_date').val("");
					$('#patientt_date').val('');
					$('#donee_date').val('');
					$('#resultt_date').val('');
					console.log(str);
					ajax.open("GET", "insert_test_date.php?q="+str,true);
					ajax.send();
				}else{
					$("#display4").html("some fields are missing");
				}
			});
			function handleResponse(response){
				console.log(JSON.parse(response));
				if(JSON.parse(response)==true){
					$('#display1').html("submit is changed,reload to update");
					$('#display2').html("submit is changed,reload to update");
					$('#display3').html("submit is changed,reload to update");
					$('#display4').html("submit is changed,reload to update");

				}else{
					$('#display1').html(" check the name of the medication");
					$('#display2').html("coudn't change date ");
					$('#display3').html("coudn't delete ");
					$('#display4').html("coudn't insert test, check the name of the test");
				}
			}
		});
	</script>
	<style>
	body{
		background: linear-gradient(to right,#D1CEE5,#A49ED1,#D1CEE5);
	}
		.container{
		margin-left:100px;
		display:flex;
		justify-content:space-between;
		width:90%;
	}
	.button {
		background-color: #4CAF50; /* Green */
		border: none;
		color: white;
		padding: 10px 15px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 10px;
		margin: 2px 1px;
		border-radius:15px;
		transition-duration: 0.4s;
		cursor: pointer;
	}
	
	
	.button2 {
		background-color: white; 
		color: black; 
		border: 1px solid #A49ED1;
	}

	.button2:hover {
		background-color: #9E98CE;
		color: white;
	}
	
	.child1{
		display:flex;
		flex-direction:column;
		border-radius: 20px;
		padding: 10px;
		border: 1px solid black;
		width:20%;
	}
	.child2{
		border-radius: 20px;
		padding: 10px;
		border: 1px solid black;
		display:flex;
		
		flex-direction:column;
		width:20%;
	}
	
	#modal {
		display: none; /* Hidden by default */
		position: fixed;/* Stay in place */
		z-index: 1; /* Sit on top */
		padding-top: 100px; /* Location of the box */
		left: 0;
		top: 0;
		width: 100%; /* Full width */
		height: 100%; /* Full height */
		overflow: auto; /* Enable scroll if needed */
		background-color: rgb(0,0,0); /* Fallback color */
		background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
	}
	#modal_2{
		display: none; /* Hidden by default */
		position: fixed;/* Stay in place */
		z-index: 1; /* Sit on top */
		padding-top: 100px; /* Location of the box */
		left: 0;
		top: 0;
		width: 100%; /* Full width */
		height: 100%; /* Full height */
		overflow: auto; /* Enable scroll if needed */
		background-color: rgb(0,0,0); /* Fallback color */
		background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
	}
#data{
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  font-size: 14px;
  height: 100px;
  overflow-y: scroll;
}

#data td {
  border: 1px solid #ddd;
  padding: 8px;
}

#data tr:nth-child(even){background-color: #f2f2f2;}

#data tr:hover {background-color: #ddd;}

#data th {
  padding-top: 12px;
  padding-bottom: 12px;
  padding-left:10px;
  text-align: left;
  background-color: #7B67FC;
  color: white;
  
}
#data1, #data2{
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  font-size: 14px;
  height: 100px;
  overflow-y: scroll;
}

#data1 td, #data2 td {
  border: 1px solid #ddd;
  padding: 8px;
}

#data1 tr:nth-child(even){background-color: #f2f2f2;}
#data2 tr:nth-child(even){background-color: #f2f2f2;}


#data1 tr:hover {background-color: #ddd;}
#data2 tr:hover {background-color: #ddd;}


#data1 th, #data2 th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7B67FC;
  color: white;
}
	/* Modal Content */
	.modal-content_1 {
	  background-color: #fefefe;
	  margin: auto;
	  border-radius:30px;
	  padding: 20px;
	  border: 1px solid #888;
	  width: 80%;
	}
	#modal_1 {
		display: none; /* Hidden by default */
		position: fixed;/* Stay in place */
		z-index: 1; /* Sit on top */
		padding-top: 100px; /* Location of the box */
		left: 0;
		top: 0;
		width: 100%; /* Full width */
		height: 100%; /* Full height */
		overflow: auto; /* Enable scroll if needed */
		background-color: rgb(0,0,0); /* Fallback color */
		background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
	}
	/* Modal Content */
	.modal-content {
	  background-color: #fefefe;
	  margin: auto;
	  border-radius:30px;
	  padding: 20px;
	  border: 1px solid #888;
	  width: 80%;
	}
	/* The Close Button */
	.close {
	  color: #aaaaaa;
	  float: right;
	  font-size: 28px;
	  font-weight: bold;
	}

	.close:hover,
	.close:focus {
	  color: #000;
	  text-decoration: none;
	  cursor: pointer;
	}
	.first_1{
		
	}
	h4,h2{
		color:#A39FCD;
		font-family:Verdana, Geneva, sans-serif;
	}
	.pp{
		font-family:Verdana, Geneva, sans-serif;
	}
	p{
		color:#E9F4FB;
		font-family:Verdana, Geneva, sans-serif;
		
	}
	.child1 div{
		color:#8B84C4;
	}
	.child2 div{
		color:#8B84C4;
	}
	
	</style>
</head>
<body>
<?php
	require 'connect.php';
	$ssn=$_GET['ssn'];
	$doc_id="";
	$doc =$conn->prepare("SELECT *
 FROM hospital.people,hospital.doctor as dd
where dd.ssn=people.ssn and 
dd.ssn='$ssn';");
	$doc->execute();
	$d=$doc->fetch(); 
		$doc_id=$d['doctor_id'];
	?>
	<div><h2>Doctor info</h2></div><br>
	<div>
		<h4>doctor </h4>
	</div>
	<div class="container" >
		<div style="background-color: white; 
		color: black; 
		border: 5px solid #A49ED1;" class="child1">
			<div >name : <?php echo $d['first_name'].' '.$d['last_name']?></div>
			<div >middle name :<?php echo $d['middle_name']?></div>
			<div >Hospital reg# :<?php echo $d['hospital_reg#']?> </div> 
			<div >tel number :<?php echo '+961 '.$d['phone_number']?></div>
			<div>department:<?php echo $d['dep_name']?></div>
			<div>extension:<?php echo $d['extension']?></div>
			<div>office:<?php echo $d['office']?></div>
			<div>experience:<?php echo $d['experience']?></div>
			<div>shift:<?php echo $d['shift']?></div>
			<div>State: <?php echo $d['state']?></div>
			<div> Change State: 
				<form action="update_doctor_state.php" method="post">
					<input type="hidden" name="ssn" value="<?php echo $ssn ?>" >
					<select style="color:#8B84C4 ; margin-top: 3%; " name="state" >
						<option value="Available" >Available</option>
						<option value="Not Available" >Not Available</option>
					</select>
					<input style="margin-top: 3%; border: 1px solid #8B84C4; background-color: white" type="submit"  value="Update" />
				</form>
			</div>
		</div>
		
		
	</div>
	<?php ?>
	<div>
		<h4>patients</h4>
	</div>
	<?php 

		$doc_p =$conn->prepare("SELECT * from doctor_patient_details where ssn= $ssn");
	$doc_p->execute();
	$doctors_p=$doc_p->fetchAll(PDO::FETCH_ASSOC); 
	
		$i=1;
	?>
		<table id="data">
			<tr>
				<th><p>patient id</p></th>
				<th><p>patient name </p></th> 
				<th><p>hospital registration</p></th>
				<th><p>phone number</p></th>
				<th><p>gender</p></th>
				<th><p>patient casetype</p></th>
				<th><p>patient room</p></th>
				<th><p>medication</p></th>
			</tr>
			<?php foreach($doctors_p as $d_p){?>
			<tr>
				<td><?php echo $d_p['patient_id']?></td>
				<td><?php echo $d_p['first_name'].' '.$d_p['last_name'] ?></td>
				<td><?php echo $d_p['hospital_reg#'] ?></td>
				<td><?php echo $d_p['phone_number'] ?></td>
				<td><?php echo $d_p['gender'] ?></td>
				<td><?php echo $d_p['patient_casetype'] ?></td>
				<td><?php echo $d_p['patient_room'] ?></td>
				
						<td><button class="button button2" onclick="insert_med('<?php echo $d_p['patient_id']?>','<?php echo $d_p['doctor_id']?>')">medical record</button></td>
					
			</tr>
			<?php
			$i++;
				}
			?>
		</table>
		<div id="modal" >
			<div class="modal-content">
				<span class="close" onclick="close_it();">&times;</span>
				<div id="show_med"style="background-color: white; 
				color: black; 
				width: 90%;
				border: 5px solid #A49ED1;" class="child2">
					
				</div>
				<br><br>
				<select style="height: 20px;border-radius:20px; border:1px solid #A49ED1;" name="up" id="up_date">
					<?php

						$stmt = $conn->prepare("SELECT name FROM medications");
						$stmt->execute();
						$meds = $stmt->fetchAll();

						foreach ($meds as $key => $value) {
						
					?>

					<option value="<?php echo $value['name'] ?>" >
						<?php echo $value['name'] ?>
					</option>

				<?php } ?>

				</select>
				<button id="unique" type="button" class="button button2">+ medication</button><br>
				<input style="border-radius:20px; border:1px solid #A49ED1;" name="up" id="de_date"/>
				<button id="unique_1" type="button" class="button button2">delete medication</button>
				<div id="display1">
				</div>
			</div>
		</div>
	<div>
		<h4>tests</h4>
	</div>
	<?php
		$testd=$conn->prepare("SELECT * FROM doctor_tests_details where ssn= $ssn;");
		$testd->execute();     
		$test_done=$testd->fetchAll(PDO::FETCH_ASSOC); 
	?>
	<table id="data1">
		<tr>
			<th>test name</th>
			<th>patient</th> 
			<th>test done date </th>
			<th>test result date</th>
			<th>delete</th>
		</tr>
		<?php
			foreach($test_done as $t){
		?>
		<tr>
			<td><?php echo $t['name'] ?></td>
			<td><?php echo $t['drfn'].' '.$t['drln'] ?></td>
			<td><?php echo $t['date_done'] ?></td>
			<td><?php echo $t['result_date'] ?></td>
			<td><button class="button button2" onclick="delete_col('<?php echo $t['test_id']?>','<?php echo $t['patient_id']?>')">delete</button></td>
		</tr>
		<?php
			}
		?>
	</table>
	<button class="button button2" onclick="showt('<?php echo $doc_id ?>');">Add New test to patient</button>
	<div id="modal_1" >
			<div class="modal-content_1">
				<span class="close" onclick="close_it();">&times;</span>
				<span class="pp">are you sure you want to delete?</span>
				<button id="unique_2" type="button" class="button button2">yes</button>
				<div id="display3">
				</div>
			</div>
	</div>
	<div id="modal_2" >
			<div class="modal-content">
				<span class="close" onclick="close_it();">&times;</span>
				<label>test name :</label>
				<select style="border-radius:20px; border:1px solid #A49ED1;" name="up" id="insert_date">
					
					<?php 
						$stmt = $conn->prepare("SELECT * from test");
						$stmt->execute();
						$testList = $stmt->fetchAll();
						foreach ($testList as $key => $value) {
							
					 ?>

					 <option value="<?php echo $value['id'] ?>" >
					 	<?php echo $value['name'] ?>
					 </option>

					<?php } ?>

				</select>
				<br><br>
				<label>patient :</label>
				<select style="border-radius:20px; border:1px solid #A49ED1;" name="up" id="patientt_date">
					
					<?php 
						$stmt = $conn->prepare("SELECT * from patient_details");
						$stmt->execute();
						$all_patients = $stmt->fetchAll();
						foreach ($all_patients as $key => $value) {

					 ?>


					 <option value="<?php echo $value['patient_id'] ?>" >
					 	<?php echo $value['f'].' '.$value['l'] ?>
					 </option>

					<?php } ?>

				</select><br><br>

				<label>result_date :</label>
				<input type="datetime-local" style="border-radius:20px; border:1px solid #A49ED1;" name="up" id="resultt_date"/><br><br>
				<button id="unique_3" type="button" class="button button2"> + test</button><br>
				<div id="display4">
				</div>

	
			</div>

		
	</div>
	<br><br>

					<?php
		$app=$conn->prepare("SELECT * FROM doctor_appointments_details where ssn = $ssn");
		$app->execute();
		$appointment=$app->fetchAll(PDO::FETCH_ASSOC);
	?>
	<table id="data2">
		<tr>
			<th><p>patient id</p></th>
			<th><p>patient name</p></th> 
			<th><p>phone number</p></th>
			<th><p>type of appointment</p></th>
			<th><p>day of appointment</p></th>
		</tr>
		<?php
			foreach($appointment as $a){
		?>
		<tr>
			<td><?php echo $a['patient_id'] ?></td>
			<td><?php echo $a['first_name'].' '.$a['last_name']?></td>
			<td><?php echo $a['phone_number'] ?></td>
			<td><?php echo $a['type'] ?></td>
			<td><?php echo $a['appointment_date'] ?></td>
		</tr>
		<?php
			}
		?>
	</table>
	<button type="submit" style="margin-top: 3%; margin-bottom: 10%;" class="button button2" onclick="$('#app_model').css('display', 'block');">Add New Appointment to patient</button>
	
		
		<div style="display: none;position: fixed; top: 30%; left: 15% ; width: 70%;" id="app_model" >
			<div class="modal-content_1">
				<span class="close" onclick="$('#app_model').css('display', 'none');">&times;</span>
				<form action="add_appointment.php" method="post" >
					<input type="hidden" name="doctor_id" value="<?php echo $doc_id ?>" >
					<input type="hidden" name="ssn" value="<?php echo $ssn ?>">

					<label>patient :</label>
				<select style="border-radius:20px; border:1px solid #A49ED1;" name="patient_id">
					
					<?php 
						foreach ($all_patients as $key => $value) {
					 ?>


					 <option value="<?php echo $value['patient_id'] ?>" >
					 	<?php echo $value['f'].' '.$value['l'] ?>
					 </option>

					<?php } ?>

				</select><br><br>

				<label>Appointment Date :</label>
				<input required type="datetime-local" style="border-radius:20px; border:1px solid #A49ED1;" name="app_date" /><br><br>

				<label>Appointment Type: </label>
				<input required type="text" name="type">
				<br>
				<br>
			
				<button type="submit" class="button button2">Add</button>
			</form>
			</div>
	</div>
	
	</body>
</html>