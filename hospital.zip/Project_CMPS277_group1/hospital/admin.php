<!DOCTYPE html>
<html>
<head>
<style>
body{
	background-color: #F5F5F5;
}
#data {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  font-size: 14px;
  height: 100px;
  overflow-y: scroll;
}

#data td, #data th {
  border: 1px solid #ddd;
  padding: 8px;
}

#data tr:nth-child(even){background-color: #f2f2f2;}

#data tr:hover {background-color: #ddd;}

#data th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: dodgerblue;
  color: white;
}

i{
	margin-left: 20%;
	cursor: pointer;
}

i:hover{
	background-color: snow;
}

.add{
	color: white;
	font-weight: bold;
	background-color: dodgerblue;
	border: 1px solid white;
	border-radius: 2%;
	padding:1%;
	float: right;
	position: relative;
	right: 5%;
	margin-bottom: 2%;
}

.window{
	position: fixed;
	top: 10%;
	left: 25%;
	background-color: white;
	width: 50%;
	border: 1px solid black;
	padding: 1%;
	overflow-y: scroll;
	max-height: 83vh;
}

label{
	min-width: 130px;
	display: inline-block;
	margin-bottom: 3%;
}

input,textarea{
	margin-bottom: 3%;
	vertical-align: top;
}

fieldset{
	border: none;
}

nav{
	width: 100%;
	display: flex;
	flex-direction: row;
	justify-content: space-around;
	align-items: center;
	height: 50px;
	background-color: dodgerblue;
	color: white;
	font-weight: bold;
	border: 1px solid grey;

}

nav a{
	/*width: 10%;*/
	height: 80%;
	vertical-align: middle;
	width: 10%;
	text-align: center;
	padding-top: 1%;
	cursor: pointer;
}

nav a:hover{
	background-color: grey;
}

.active{
	background-color: grey;
}


</style>
	<title>Admin Page</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
</head>
<body>

<nav>
	<a class="active" onclick="displayPeople(this)" >People</a>
	<a onclick="displayEmployee(this)" >Employees</a>
	<a onclick="displayPatient(this)" >Patients</a>
	<a onclick="displayDoctor(this)" >Doctors</a>
	<a onclick="displayNurse(this)" >Nurses</a>
	<a onclick="displayStaff(this)" >Staff</a>
	<a onclick="displayMedication(this)" >Medications</a>
	<a onclick="displayTest(this)" >Tests</a>
	<a onclick="displayBlood(this)" >Blood Bank</a>

</nav>



<div id="medication_div" style="display: none;">

<table id="data">

	<h2>Medications Table: </h2>
	<button onclick="$('#med_window').css('display', 'block');" class="add">Add new medication <i style="margin-left: 0" class="fa fa-plus" ></i></button>

	<tr>
    <th>id</th>
    <th>Name</th>
    <th>Description</th>
    <th>Edit/Delete</th>
  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from medications");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['id']; ?></td>
	    <td id="med_name<?php echo $item['id']; ?>" ><?php echo $item['name']; ?></td>
	    <td id="med_description<?php echo $item['id']; ?>" ><?php echo $item['description']; ?></td>
	    <td><i onclick="showEditMed('<?php echo $item['id']; ?>');" class="fa fa-edit"></i>  <i class="fa fa-remove" onclick="deleteRecord('medications', '<?php echo $item['id']; ?>')" ></i></td>
	  </tr>
	<?php } ?>	  
  
</table>

	<div style="display: none;" id="med_window" class="window">
		<i style="float: right; position: relative;" onclick="$('#med_window').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="add_medication.php" method="post">
		<legend>Add new medication</legend><br>

		<label>Medication name:</label><input type="text" name="name" required><br>

		<label>Description: </label><textarea name="description" cols="50" rows="6" required></textarea>
		<br>

		<button type="submit" class="add" >Insert</button>

		</form>

	</fieldset>
	</div>

	<div style="display: none;" id="med_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#med_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_medication.php" method="post">
		<legend>Edit medication</legend><br>

		<input type="number" id="in_med_id" hidden name="med_id">

		<label>Medication name:</label><input id="in_med_name" type="text" name="name" required><br>

		<label>Description: </label><textarea id="in_med_description" name="description" cols="50" rows="6" required></textarea><br>

		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>


	<br><br>

</div>


<div id="blood_div" style="display: none;">

<table id="data">

	<h2>Blood Bank Table: </h2>
	<button onclick="$('#blood_window').css('display', 'block');" class="add">Add new Blood Unit <i style="margin-left: 0" class="fa fa-plus" ></i></button>

	<tr>
    <th>id</th>
    <th>hospital_id</th>
    <th>type</th>
    <th>amount</th>
    <th>Edit/Delete</th>
  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from bloodunit");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['id']; ?></td>
	    <td id="blood_hospitalid<?php echo $item['id']; ?>" ><?php echo $item['hospId']; ?></td>
	    <td id="blood_type<?php echo $item['id']; ?>" ><?php echo $item['type']; ?></td>
	    <td id="blood_amount<?php echo $item['id']; ?>" ><?php echo $item['amount']; ?></td>
	    <td><i onclick="showEditBlood('<?php echo $item['id']; ?>');" class="fa fa-edit"></i>  <i class="fa fa-remove" onclick="deleteRecord('bloodunit', '<?php echo $item['id']; ?>')" ></i></td>
	  </tr>
	<?php } ?>	  
  
</table>

	<div style="display: none;" id="blood_window" class="window">
		<i style="float: right; position: relative;" onclick="$('#blood_window').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="add_blood.php" method="post">
		<legend>Add new Blood Unit</legend><br>

		<label>Type:</label>
		<select name="type" >
			<option value="A+" >A+</option>
			<option value="A-" >A-</option>
			<option value="B+" >B+</option>
			<option value="B-" >B-</option>
			<option value="O+" >O+</option>
			<option value="O-" >O-</option>
			<option value="AB+" >AB+</option>
			<option value="AB-" >AB-</option>
		</select><br>

		<label>Amount: </label><input type="number" name="amount" required>

		<button type="submit" class="add" >Insert</button>

		</form>

	</fieldset>
	</div>

	<div style="display: none;" id="blood_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#blood_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_blood.php" method="post">
		<legend>Edit Blood Unit</legend><br>

		<input type="number" id="in_blood_id" hidden name="blood_id">
		<label>Type:</label>
			<select id="in_blood_type"  name="type" >
				<option value="A+" >A+</option>
				<option value="A-" >A-</option>
				<option value="B+" >B+</option>
				<option value="B-" >B-</option>
				<option value="O+" >O+</option>
				<option value="O-" >O-</option>
				<option value="AB+" >AB+</option>
				<option value="AB-" >AB-</option>
			</select><br>

		<label>Amount: </label><input id="in_amount" type="number" name="amount" required>


		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>


	<br><br>

</div>


<div id="test_div" style="display: none;">


<table id="data">

	<h2>Tests Table: </h2>
	<button onclick="$('#test_window').css('display', 'block');" class="add">Add new Test <i style="margin-left: 0" class="fa fa-plus" ></i></button>

	<tr>
    <th>Id</th>
    <th>Test name</th>
    <th>Edit/Delete</th>
  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from test");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['id']; ?></td>
	    <td id="test_name<?php echo $item['id']; ?>" ><?php echo $item['name']; ?></td>
	    <td><i onclick="showEditTest('<?php echo $item['id']; ?>');" class="fa fa-edit"></i>  <i class="fa fa-remove" onclick="deleteRecord('test', '<?php echo $item['id']; ?>')" ></i></td>
	  </tr>
	<?php } ?>	  
  
</table>

	<div style="display: none;" id="test_window" class="window">
		<i style="float: right; position: relative;" onclick="$('#test_window').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="add_test.php" method="post">
		<legend>Add new Test</legend><br>

		<label>Test name:</label><input type="text" name="name" required><br>

		<button type="submit" class="add" >Insert</button>

		</form>

	</fieldset>
	</div>

	<div style="display: none;" id="test_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#test_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_test.php" method="post">
		<legend>Edit Test</legend><br>

		<input type="number" id="in_test_id" hidden name="test_id">

		<label>Test name:</label><input id="in_test_name" type="text" name="name" required><br>

		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>

	<br>
	<br>

</div>

	<div id="people_div">


	<table id="data">

	<h2>People Table: </h2>
	<button onclick="$('#people_window').css('display', 'block');" class="add">Add new Person <i style="margin-left: 0" class="fa fa-plus" ></i></button>

	<tr>
    <th>ssn</th>
    <th>first_name</th>
    <th>middle_name</th>
    <th>last_name</th>
    <th>hospital_reg#</th>
    <th>phone_number</th>
    <th>gender</th>
    <th>depratment</th>
    <th>type</th>
    <th>Edit/Delete</th>
  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from people");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['ssn']; ?></td>
	    <td id="people_fname<?php echo $item['ssn']; ?>" ><?php echo $item['first_name']; ?></td>
	    <td id="people_mname<?php echo $item['ssn']; ?>" ><?php echo $item['middle_name']; ?></td>
	    <td id="people_lname<?php echo $item['ssn']; ?>" ><?php echo $item['last_name']; ?></td>
	    <td id="people_reg<?php echo $item['ssn']; ?>" ><?php echo $item['hospital_reg#']; ?></td>
	    <td id="people_phone<?php echo $item['ssn']; ?>" ><?php echo $item['phone_number']; ?></td>
	    <td id="people_gender<?php echo $item['ssn']; ?>" ><?php echo $item['gender']; ?></td>
	    <td id="people_department<?php echo $item['ssn']; ?>" ><?php echo $item['dep_name'];?></td>
	    <td id="people_type<?php echo $item['ssn']; ?>" ><?php echo $item['type']; ?></td>

	    <td><i onclick="showEditPeople('<?php echo $item['ssn']; ?>');" class="fa fa-edit"></i>  <i class="fa fa-remove" onclick="deleteRecord('people', '<?php echo $item['ssn']; ?>')"></i></td>
	  </tr>
	<?php } ?>	  
  
</table>

	<div style="display: none;" id="people_window" class="window">
		<i style="float: right; position: relative;" onclick="$('#people_window').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="add_people.php" method="post">
		<legend>Add new Person</legend><br>

		<label>First Name:</label><input type="text" name="first_name" required><br>
		<label>Middle Name:</label><input type="text" name="middle_name" placeholder="Optional"><br>
		<label>Last Name:</label><input type="text" name="last_name" required><br>
		<label>Phone Number:</label><input type="number" name="phone"><br>

		<label>Gender:</label>
		<select name="gender" >
			<option value="male" >Male</option>
			<option value="female" >Female</option>
		</select><br>


		<label>Department:</label>
		<select name="dep_name" >
			<?php 

				$stmt = $conn->prepare("SELECT * FROM department");
				$stmt->execute();

				$departments = $stmt->fetchAll();

				foreach ($departments as $key => $department) {
				
			 ?>

			 <option value="<?php echo $department['Deptname']  ?>" ><?php echo $department['Deptname']  ?></option>

			<?php } ?>
		</select>
		<br>

		<label>Person Type:</label>
		<select name="main_type" onchange="main_type_change(this)">
			<option value="employee">Employee</option>
			<option value="patient">Patient</option>
		</select>
		<br>

		<div>
		<label>Secondary Type:</label>
		<select  id="sec_type"  name="sec_type" onchange="sec_type_change(this)">
			<option value="doctor" >Doctor</option>
			<option value="staff">Staff</option>
			<option value="nurse" >Nurse</option>
		</select>

	</div>

		<div style="display: none;" id="patient_stuff">
			<label>Case Type:</label>
			<input type="text" name="case_type"><br>

			<label>Medical Record:</label>
			<textarea  name="medical_record" cols="50" rows="6"></textarea><br>

			<label>Room:</label>
			<select name="room">
			<?php 

			$stmt = $conn->prepare("SELECT extension, state, number_of_beds FROM room");
			$stmt->execute();
			$rooms = $stmt->fetchAll();

			foreach ($rooms as $key => $room) {
			?>

			<option <?php if($room['state'] == 'full'){ ?>
					disabled <?php } ?>

			  value="<?php echo $room['extension'] ?>" ><?php echo $room['extension'].' '. $room['state'].' '.$room['number_of_beds'] ?> beds</option>

		<?php } ?>
			
		</select><br>

		</div>

		<div id="employee_stuff">
			
			<label>Bank Account:</label>
			<input type="text" name="bank_account"><br>


			<label>Location:</label>
			<input type="text" name="location"><br>


			<label>Email:</label>
			<input type="email" name="email"><br>


			<label>Study Degree:</label>
			<input type="text" name="study_degree"><br>

		</div>

		<div id="doctor_stuff" >
			
			<label>Shift:</label><input type="text" name="shift" placeholder=" e.g: day or night"><br>
			<label>Office:</label><input type="text" name="office"><br>
			<label>Extension:</label><input type="number" name="extension"><br>
			<label>State:</label>
				<select name="state" >
					<option value="available" >Available</option>
					<option value="not available" >Not Available</option>
				</select>
				<br>
			<label>Experience:</label><textarea  name="experience" cols="50" rows="6"></textarea><br>

		</div>

		<div style="display: none;" id="nurse_stuff" >
			
			<label>Shifts:</label><input type="text" name="shifts"><br>
			<label>Floor:</label><input type="number" name="floor"><br>

			<label>Supervisor(nurse_id/Name):</label>
		<select name="supervisor">

			<option value="NULL" >NULL</option>

			<?php 

			$stmt = $conn->prepare("SELECT p.first_name, p.last_name, n.nurse_id from nurse n, people p where n.ssn = p.ssn");
			$stmt->execute();
			$nurses = $stmt->fetchAll();

			foreach ($nurses as $key => $nurse) {
			?>

			<option value="<?php echo $nurse['nurse_id'] ?>" ><?php echo $nurse['nurse_id'].' '. $nurse['first_name'].' '.$nurse['last_name'] ?></option>

		<?php } ?>
			
		</select>

		</div>

		<div style="display: none;" id="staff_stuff" >
			
			<label>Type/Role:</label><input type="text" name="staff_type"><br>
			<label>Salary:</label><input type="number" name="salary"><br>

			<label>Description:</label><textarea  name="description" cols="50" rows="6"></textarea><br>
			

		</div>

		<button type="submit" class="add" >Insert</button>

		</form>

	</fieldset>
	</div>

	<div style="display: none;" id="people_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#people_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_people.php" method="post">
		<legend>Edit People</legend><br>

		<input type="number" id="in_people_ssn" hidden name="people_ssn">

		<label>first name:</label><input id="in_people_fname" type="text" name="fname" required><br>
		<label>middle name:</label><input id="in_people_mname" type="text" name="mname"><br>
		<label>last name:</label><input id="in_people_lname" type="text" name="lname" required><br>
		<label>Phone number:</label><input id="in_people_phone" type="text" name="phone" required><br>
		<label>Gender:</label>
		<select id="in_people_gender" name="gender">
			<option value="Male">Male</option>
			<option value="Female">Female</option>
		</select>

		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>


	<br><br>

</div>

<div id="employee_div" style="display: none;">


	<table id="data">

	<h2>Employee Table: </h2>

	<tr>
    <th>hospital_id</th>
    <th>ssn</th>
    <th>bank_account</th>
    <th>location</th>
    <th>email</th>
    <th>study_degree</th>
    <th>Edit</th>
  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from employee");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['hospital_id']; ?></td>
	    <td id="emp_ssn<?php echo $item['hospital_id']; ?>" ><?php echo $item['ssn']; ?></td>
	    <td id="emp_bank<?php echo $item['hospital_id']; ?>" ><?php echo $item['bank_account']; ?></td>
	    <td id="emp_location<?php echo $item['hospital_id']; ?>" ><?php echo $item['location']; ?></td>
	    <td id="emp_email<?php echo $item['hospital_id']; ?>" ><?php echo $item['email']; ?></td>
	    <td id="emp_study<?php echo $item['hospital_id']; ?>" ><?php echo $item['study_degree']; ?></td>

	    <td><i onclick="showEditEmployee('<?php echo $item['hospital_id']; ?>');" class="fa fa-edit"></i></td>
	  </tr>
	<?php } ?>	  
  
</table>


	<div style="display: none;" id="emp_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#emp_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_employee.php" method="post">
		<legend>Edit Employee</legend><br>

		<input type="number" id="in_emp_hospital_id" hidden name="emp_hospital_id">

		<label>Bank Accnount:</label><input id="in_emp_bank" type="text" name="bank" required><br>
		<label>Location:</label><input id="in_emp_location" type="text" name="location"><br>
		<label>Email:</label><input id="in_emp_email" type="email" name="email" required><br>
		<label>Study Degree:</label><input id="in_emp_study" type="text" name="study" required><br>
	
		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>

	<br><br>

</div>

<div id="patient_div" style="display: none;">



<table id="data">

	<h2>Patients Table: </h2>

	<tr>
    <th>patient_id</th>
    <th>ssn</th>
    <th>case_type</th>
    <th>medical record</th>
    <th>room</th>
    <th>Edit</th>
  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from patient");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['patient_id']; ?></td>
	    <td id="patient_ssn<?php echo $item['patient_id']; ?>" ><?php echo $item['ssn']; ?></td>
	    <td id="patient_case<?php echo $item['patient_id']; ?>" ><?php echo $item['patient_casetype']; ?></td>
	    <td id="patient_record<?php echo $item['patient_id']; ?>" ><?php echo $item['patient_medical_record']; ?></td>
	    <td id="patient_room<?php echo $item['patient_id']; ?>" ><?php echo $item['patient_room']; ?></td>

	    <td><i onclick="showEditPatient('<?php echo $item['patient_id']; ?>');" class="fa fa-edit"></i></td>
	  </tr>
	<?php } ?>	  
  
</table>


	<div style="display: none;" id="patient_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#patient_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_patient.php" method="post">
		<legend>Edit Patient</legend><br>

		<input type="number" id="in_patient_id" hidden name="patient_id">

		<label>Case Type:</label><input id="in_case" type="text" name="case" required><br>
		<label>Medical Record:</label><input id="in_record" type="text" name="record"><br>

		<label>Room Extension:</label>
		<select name="room" id="in_room">
			<?php 

			$stmt = $conn->prepare("SELECT extension, state, number_of_beds FROM room");
			$stmt->execute();
			$rooms = $stmt->fetchAll();

			foreach ($rooms as $key => $room) {
			?>

			<option <?php if($room['state'] == 'full'){ ?>
					disabled <?php } ?>

			  value="<?php echo $room['extension'] ?>" ><?php echo $room['extension'].' '. $room['state'].' '.$room['number_of_beds'] ?> beds</option>

		<?php } ?>
			
		</select>

		<br>
	
		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>


		<br><br>

	</div>

<div id="staff_div" style="display: none;">


<table id="data">

	<h2>Staff Table: </h2>

	<tr>
    <th>staff_id</th>
    <th>ssn</th>
    <th>hospital_id</th>
    <th>type</th>
    <th>salary</th>
    <th>Description</th>
    <th>Edit</th>
  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from staff");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['staff_id']; ?></td>
	    <td id="staff_ssn<?php echo $item['staff_id']; ?>" ><?php echo $item['ssn']; ?></td>
	    <td id="staff_hospitalid<?php echo $item['staff_id']; ?>" ><?php echo $item['hospital_id']; ?></td>
	    <td id="staff_type<?php echo $item['staff_id']; ?>" ><?php echo $item['type']; ?></td>
	    <td id="staff_salary<?php echo $item['staff_id']; ?>" ><?php echo $item['salary']; ?></td>
	    <td id="staff_description<?php echo $item['staff_id']; ?>" ><?php echo $item['description']; ?></td>
	    <td><i onclick="showEditStaff('<?php echo $item['staff_id']; ?>');" class="fa fa-edit"></i> </td>
	  </tr>
	<?php } ?>	  
  
</table>


	<div style="display: none;" id="staff_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#staff_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_staff.php" method="post">
		<legend>Edit Staff</legend><br>

		<input type="number" id="in_staff_id" hidden name="staff_id">

		<label>Type:</label><input id="in_type" type="text" name="type" required><br>
		<label>Salary:</label><input id="in_salary" type="number" name="salary"><br>

		<label>Description:</label>
		<textarea id="in_staff_description"  name="description" cols="50" rows="6" required></textarea>

		<br>
	
		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>


	<br><br>


</div>
<div id="nurse_div" style="display: none;">


	<table id="data">

	<h2>Nurses Table: </h2>

	<tr>
    <th>nurse_id</th>
    <th>ssn</th>
    <th>hospital_id</th>
    <th>shifts</th>
    <th>floor</th>
    <th>supervisor_id</th>
    <th>Edit</th>

  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from nurse");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['nurse_id']; ?></td>
	    <td id="nurse_ssn<?php echo $item['nurse_id']; ?>" ><?php echo $item['ssn']; ?></td>
	    <td id="nurse_hospitalid<?php echo $item['nurse_id']; ?>" ><?php echo $item['hospital_id']; ?></td>
	    <td id="nurse_shifts<?php echo $item['nurse_id']; ?>" ><?php echo $item['shifts']; ?></td>
	    <td id="nurse_floor<?php echo $item['nurse_id']; ?>" ><?php echo $item['floor']; ?></td>
	    <td id="nurse_supervisor<?php echo $item['nurse_id']; ?>" ><?php echo $item['supervisor_id']; ?></td>

	    <td><i onclick="showEditNurse('<?php echo $item['nurse_id']; ?>');" class="fa fa-edit"></i></td>
	  </tr>
	<?php } ?>	  
  
</table>


	<div style="display: none;" id="nurse_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#nurse_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_nurse.php" method="post">
		<legend>Edit Nurse</legend><br>

		<input type="number" id="in_nurse_id" hidden name="nurse_id">

		<label>Shifts:</label><input id="in_shifts" type="text" name="shifts" required><br>
		<label>floor:</label><input id="in_floor" type="number" name="floor"><br>

		<label>Supervisor(nurse_id/Name):</label>
		<select name="supervisor" id="in_supervisor_id">

			<option value="NULL" >NULL</option>

			<?php 

			$stmt = $conn->prepare("SELECT p.first_name, p.last_name, n.nurse_id from nurse n, people p where n.ssn = p.ssn");
			$stmt->execute();
			$nurses = $stmt->fetchAll();

			foreach ($nurses as $key => $nurse) {
			?>

			<option id="soption" value="<?php echo $nurse['nurse_id'] ?>" ><?php echo $nurse['nurse_id'].' '. $nurse['first_name'].' '.$nurse['last_name'] ?></option>

		<?php } ?>
			
		</select>

		<br>
	
		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>


<br><br>

</div>

<div id="doctor_div" style="display: none;">


	<table id="data">

	<h2>Doctors Table: </h2>

	<tr>
    <th>doctor_id</th>
    <th>ssn</th>
    <th>hospital_id</th>
    <th>shift</th>
    <th>office</th>
    <th>extension</th>
    <th>state</th>
    <th>experience</th>
    <th>Edit/Delete</th>

  </tr>


	<?php 

		require 'connect.php';

		$stmt = $conn->prepare("Select * from doctor");
		$stmt->execute();
		$items = $stmt->fetchAll();

		foreach ($items as $key => $item) {

	 ?>

  
	  <tr>
	    <td><?php echo $item['doctor_id']; ?></td>
	    <td id="doctor_ssn<?php echo $item['doctor_id']; ?>" ><?php echo $item['ssn']; ?></td>
	    <td id="doctor_hospitalid<?php echo $item['doctor_id']; ?>" ><?php echo $item['hospital_id']; ?></td>
	    <td id="doctor_shift<?php echo $item['doctor_id']; ?>" ><?php echo $item['shift']; ?></td>
	    <td id="doctor_office<?php echo $item['doctor_id']; ?>" ><?php echo $item['office']; ?></td>
	    <td id="doctor_extension<?php echo $item['doctor_id']; ?>" ><?php echo $item['extension']; ?></td>
	     <td id="doctor_state<?php echo $item['doctor_id']; ?>" ><?php echo $item['state']; ?></td>
 		<td id="doctor_experience<?php echo $item['doctor_id']; ?>" ><?php echo $item['experience']; ?></td>
	    <td><i onclick="showEditDoctor('<?php echo $item['doctor_id']; ?>');" class="fa fa-edit"></i></td>
	  </tr>
	<?php } ?>	  
  
</table>


	<div style="display: none;" id="doctor_ewindow" class="window">
		<i style="float: right; position: relative;" onclick="$('#doctor_ewindow').css('display', 'none');"  class="fa fa-remove" ></i><br>
		
	<fieldset>
		<form action="edit_doctor.php" method="post">
		<legend>Edit Doctor</legend><br>

		<input type="number" id="in_doctor_id" hidden name="doctor_id">

		<label>Shift:</label><input id="in_shift" type="text" name="shift" required><br>
		<label>Office:</label><input id="in_office" type="text" name="office"><br>
		<label>Extension:</label><input id="in_extension" type="number" name="extension"><br>

		<label>State:</label>
		<select name="state" id="in_state">

			<option value="available" >Available</option>
			<option value="not available" >Not Available</option>
			
		</select>

		<br>
		<label>Experience:</label>
		<textarea id="in_doctor_experience"  name="experience" cols="50" rows="6" required></textarea>

		<br>
	
		<button type="submit" class="add" >Update</button>

		</form>

	</fieldset>
	</div>

</div>





	<script type="text/javascript">

		let previous = -1;

		function deleteRecord(table, id){
			var result = confirm('Are you sure you want to delete '+table+' with id '+id);

			if(result){

				$.ajax({
	        url: 'delete.php',
	        method: 'post',
	        data: {'table': table, 'id': id},
	        dataType: 'json',
	        success: function (response) {
	        	if(response.error){
	        		alert(response.message);
	        	}
	        	else
	        	{
	        		alert(response.message);
	        		location.reload();
	        	}
	        }

	    });

			}
		}
		
		function showEditMed(id){

			$('#med_ewindow').css('display', 'block');
			$('#in_med_name').val($('#med_name'+id).html());
			$('#in_med_description').val($('#med_description'+id).html());
			$('#in_med_id').val(id);

		}

		function showEditTest(id){

			$('#test_ewindow').css('display', 'block');
			$('#in_test_name').val($('#test_name'+id).html());
			$('#in_test_id').val(id);

		}

		function showEditPeople(id){

			$('#people_ewindow').css('display', 'block');
			$('#in_people_fname').val($('#people_fname'+id).html());
			$('#in_people_lname').val($('#people_lname'+id).html());
			$('#in_people_mname').val($('#people_mname'+id).html());
			$('#in_people_phone').val($('#people_phone'+id).html());
			$('#in_people_gender').val($('#people_gender'+id).html());
			$('#in_people_ssn').val(id);

		}

		function showEditEmployee(id){

			$('#emp_ewindow').css('display', 'block');
			$('#in_emp_bank').val($('#emp_bank'+id).html());
			$('#in_emp_location').val($('#emp_location'+id).html());
			$('#in_emp_email').val($('#emp_email'+id).html());
			$('#in_emp_study').val($('#emp_study'+id).html());
			$('#in_emp_hospital_id').val(id);

		}

		function showEditPatient(id){

			$('#patient_ewindow').css('display', 'block');
			$('#in_case').val($('#patient_case'+id).html());
			$('#in_record').val($('#patient_record'+id).html());
			$('#in_room').val($('#patient_room'+id).html());
			$('#in_patient_id').val(id);

		}

		function showEditStaff(id){

			$('#staff_ewindow').css('display', 'block');
			$('#in_type').val($('#staff_type'+id).html());
			$('#in_salary').val($('#staff_salary'+id).html());
			$('#in_staff_description').val($('#staff_description'+id).html());
			$('#in_staff_id').val(id);

		}

		function showEditNurse(id){

			$('#nurse_ewindow').css('display', 'block');
			$('#in_shifts').val($('#nurse_shifts'+id).html());
			$('#in_floor').val($('#nurse_floor'+id).html());
			$('#in_supervisor_id').val($('#nurse_supervisor'+id).html());
			$('#in_nurse_id').val(id);

			$('#in_supervisor_id option[value="'+id+'"]').prop('disabled', true);
			$('#in_supervisor_id option[value="'+previous+'"]').prop('disabled', false);
			previous = id;

		}

		function showEditDoctor(id){

			$('#doctor_ewindow').css('display', 'block');
			$('#in_shift').val($('#doctor_shift'+id).html());
			$('#in_office').val($('#doctor_office'+id).html());
			$('#in_extension').val($('#doctor_extension'+id).html());
			$('#in_state').val($('#doctor_state'+id).html());
			$('#in_doctor_experience').val($('#doctor_experience'+id).html());
			$('#in_doctor_id').val(id);
		}

		function showEditBlood(id){

			$('#blood_ewindow').css('display', 'block');
			$('#in_blood_type').val($('#blood_type'+id).html());
			$('#in_amount').val($('#blood_amount'+id).html());
			$('#in_blood_id').val(id);
		}


		function displayPeople(element){
			$('#people_div').css('display', 'block');

			$('#patient_div').css('display', 'none');
			$('#nurse_div').css('display', 'none');
			$('#doctor_div').css('display', 'none');
			$('#employee_div').css('display', 'none');
			$('#staff_div').css('display', 'none');
			$('#test_div').css('display', 'none');
			$('#medication_div').css('display', 'none');
			$('#blood_div').css('display', 'none');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

			function displayEmployee(element){
			$('#people_div').css('display', 'none');

			$('#patient_div').css('display', 'none');
			$('#nurse_div').css('display', 'none');
			$('#doctor_div').css('display', 'none');
			$('#employee_div').css('display', 'block');
			$('#staff_div').css('display', 'none');
			$('#test_div').css('display', 'none');
			$('#medication_div').css('display', 'none');
			$('#blood_div').css('display', 'none');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

			function displayPatient(element){
			$('#people_div').css('display', 'none');

			$('#patient_div').css('display', 'block');
			$('#nurse_div').css('display', 'none');
			$('#doctor_div').css('display', 'none');
			$('#employee_div').css('display', 'none');
			$('#staff_div').css('display', 'none');
			$('#test_div').css('display', 'none');
			$('#medication_div').css('display', 'none');
			$('#blood_div').css('display', 'none');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

			function displayStaff(element){
			$('#people_div').css('display', 'none');

			$('#patient_div').css('display', 'none');
			$('#nurse_div').css('display', 'none');
			$('#doctor_div').css('display', 'none');
			$('#employee_div').css('display', 'none');
			$('#staff_div').css('display', 'block');
			$('#test_div').css('display', 'none');
			$('#medication_div').css('display', 'none');
			$('#blood_div').css('display', 'none');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

			function displayNurse(element){
			$('#people_div').css('display', 'none');

			$('#patient_div').css('display', 'none');
			$('#nurse_div').css('display', 'block');
			$('#doctor_div').css('display', 'none');
			$('#employee_div').css('display', 'none');
			$('#staff_div').css('display', 'none');
			$('#test_div').css('display', 'none');
			$('#medication_div').css('display', 'none');
			$('#blood_div').css('display', 'none');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

			function displayDoctor(element){
			$('#people_div').css('display', 'none');

			$('#patient_div').css('display', 'none');
			$('#nurse_div').css('display', 'none');
			$('#doctor_div').css('display', 'block');
			$('#employee_div').css('display', 'none');
			$('#staff_div').css('display', 'none');
			$('#test_div').css('display', 'none');
			$('#medication_div').css('display', 'none');
			$('#blood_div').css('display', 'none');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

			function displayTest(element){
			$('#people_div').css('display', 'none');

			$('#patient_div').css('display', 'none');
			$('#nurse_div').css('display', 'none');
			$('#doctor_div').css('display', 'none');
			$('#employee_div').css('display', 'none');
			$('#staff_div').css('display', 'none');
			$('#test_div').css('display', 'block');
			$('#medication_div').css('display', 'none');
			$('#blood_div').css('display', 'none');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

			function displayMedication(element){
			$('#people_div').css('display', 'none');

			$('#patient_div').css('display', 'none');
			$('#nurse_div').css('display', 'none');
			$('#doctor_div').css('display', 'none');
			$('#employee_div').css('display', 'none');
			$('#staff_div').css('display', 'none');
			$('#test_div').css('display', 'none');
			$('#medication_div').css('display', 'block');
			$('#blood_div').css('display', 'none');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

		function displayBlood(element){
			$('#people_div').css('display', 'none');

			$('#patient_div').css('display', 'none');
			$('#nurse_div').css('display', 'none');
			$('#doctor_div').css('display', 'none');
			$('#employee_div').css('display', 'none');
			$('#staff_div').css('display', 'none');
			$('#test_div').css('display', 'none');
			$('#medication_div').css('display', 'none');
			$('#blood_div').css('display', 'block');


			var previous = document.getElementsByClassName('active');
  			previous[0].className = previous[0].className.replace("active", "");

  			element.className += " active";

		}

		function main_type_change(element){
			if(element.value == "employee"){

				$('#employee_stuff').css('display','block');
				$('#doctor_stuff').css('display','block');
				$('#patient_stuff').css('display', 'none');
				$('#sec_type').prop('disabled', false);
				$('#sec_type').val('doctor');
			

			}

			else if(element.value == "patient"){
				$('#employee_stuff').css('display', 'none');
				$('#doctor_stuff').css('display', 'none');
				$('#nurse_stuff').css('display', 'none');
				$('#staff_stuff').css('display', 'none');
				$('#patient_stuff').css('display', 'block');
				$('#sec_type').prop('disabled', true);

			}

		}

		function sec_type_change(element){
			if(element.value == "staff"){

				$('#staff_stuff').css('display','block');
				$('#nurse_stuff').css('display', 'none');
				$('#doctor_stuff').css('display', 'none');

			}

			else if(element.value == "doctor"){
				
				$('#staff_stuff').css('display','none');
				$('#nurse_stuff').css('display', 'none');
				$('#doctor_stuff').css('display', 'block');

			}

			else if(element.value == "nurse"){
				
				$('#staff_stuff').css('display','none');
				$('#nurse_stuff').css('display', 'block');
				$('#doctor_stuff').css('display', 'none');

			}


		}
	

	</script>
	

</body>
</html>
