<?php

	require 'connect.php';

	if(isset($_POST['ssn']) && isset($_POST['state'])){

		
		$state = $_POST['state']; 
		$ssn = $_POST['ssn'];

		$stmt = $conn->prepare("UPDATE doctor SET state = '$state' WHERE ssn = $ssn");

		try{

		$stmt->execute();

		echo "<script>alert(' Updated');  location.replace('Doctor.php?ssn=$ssn') </script>";


	}
	catch(PDOException $e){
		echo "<script>alert(' Cant Update');  window.history.back(); </script>";
	}

	}

?>