<?php
	require 'connect.php';
	$reciever=explode("~",$_GET['q']);
	$a=$reciever[0];
	$b=$reciever[1];
	$c=$reciever[2];
	$c=$reciever[2];

	try{
		$delete_=$conn->prepare("DELETE from hospital.appointment where appointment_date='$a' and patient_id='$b' and doctor_id='$c';");
		if($delete_->execute()){
			echo "true";
		}else
		{
			echo "false";
		}
	}catch (PDOException $e){
		echo "false";
	}
?>