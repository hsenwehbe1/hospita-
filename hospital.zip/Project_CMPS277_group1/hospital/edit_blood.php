<?php

	require 'connect.php';

	if(isset($_POST['blood_id']) && isset($_POST['type']) && isset($_POST['amount'])){

		$blood_id = $_POST['blood_id'];
		$type = $_POST['type'];
		$amount = $_POST['amount'];

		$stmt = $conn->prepare("UPDATE bloodunit SET amount = $amount, type = '$type' where id = $blood_id");
		try{

		$stmt->execute();

		echo "<script>alert('Blood Unit Updated');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('Cannot update');  location.replace('admin.php'); </script>";
	}
	}

?>