<?php
	require 'connect.php';
	$reciever=explode("~",$_GET['q']);
	$a=$reciever[0];
	$b=$reciever[1];
	try{
		$delete_=$conn->prepare("DELETE from test_done where test_id='$a' and patient_id='$b';");
		if($delete_->execute()){
			echo "true";
		}else
		{
			echo "false";
		}
	}catch (PDOException $e){
		echo "false";
	}
?>