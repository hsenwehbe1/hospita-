<?php
	require 'connect.php';
	$reciever=$_GET['q'];
					$medic =$conn->prepare("SELECT * FROM `patient_medications_details` WHERE patient_id = $reciever");
		$medic->execute();
		$medication=$medic->fetchAll(PDO::FETCH_ASSOC);
		foreach($medication as $m){
		echo '
					<div>-medication name:'.
					$m['name'].'</div><br>
					<div>description :'.$m['description'].'</div>
					<br>
					
				';
		}
?>