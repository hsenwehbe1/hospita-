<?php

	require 'connect.php';

	if(isset($_POST['doctor_id']) && isset($_POST['patient_id']) && isset($_POST['ssn']) ){

		$doctor_id = $_POST['doctor_id'];
		$patient_id = $_POST['patient_id']; 
		$ssn = $_POST['ssn'];

		$stmt = $conn->prepare("INSERT INTO doctor_patient values($doctor_id,$patient_id)");

		try{

		$stmt->execute();

		echo "<script>alert(' Added');  location.replace('Patient.php?ssn=$ssn') </script>";


	}
	catch(PDOException $e){
		echo "<script>alert(' already exists');  window.history.back(); </script>";
	}

	}

?>