<?php

	require 'connect.php';

	if(isset($_POST['bank']) && isset($_POST['location']) && isset($_POST['email']) && isset($_POST['study']) && isset($_POST['emp_hospital_id'])){

		$bank = $_POST['bank'];
		$location = $_POST['location'];
		$email = $_POST['email'];
		$study = $_POST['study'];

		$hospital_id = $_POST['emp_hospital_id'];
		

		$stmt = $conn->prepare("UPDATE employee SET bank_account = '$bank', location = '$location', email = '$email', study_degree = '$study' where hospital_id = $hospital_id");
		
		try{

		$stmt->execute();

		echo "<script>alert('Employee info updated');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('cannot update');  location.replace('admin.php'); </script>";
	}
	}

?>