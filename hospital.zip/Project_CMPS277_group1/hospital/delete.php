<?php

	require 'connect.php';

	$result = array();
		
	if(isset($_POST['table']) && isset($_POST['id'])){

		$table = $_POST['table'];
		$id = $_POST['id'];

		$sql = "";

		if($table == "medications" || $table == "test" || $table == "bloodunit"){
			$sql = "DELETE FROM $table WHERE id = $id";
		}

		else if($table == "people"){
			$sql = "DELETE FROM people WHERE ssn = $id";
		}



		$stmt = $conn->prepare($sql);
		$stmt->execute();

		$result['message'] = "Deleted successfully";
		$result['error'] = false;
	}

	else{
		$result['message'] = "Missing fields";
		$result['error'] = true;

	}

	echo json_encode($result);

?>