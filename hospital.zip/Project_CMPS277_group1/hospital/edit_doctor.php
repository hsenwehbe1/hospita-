<?php

	require 'connect.php';

	if(isset($_POST['doctor_id']) && isset($_POST['shift']) && isset($_POST['office']) && isset($_POST['extension']) && isset($_POST['state']) && isset($_POST['experience'])){

		$doctor_id = $_POST['doctor_id'];
		$shift = $_POST['shift'];
		$office = $_POST['office'];
		$extension = $_POST['extension'];
		$state = $_POST['state'];
		$experience = $_POST['experience'];


		$stmt = $conn->prepare("UPDATE doctor SET shift = '$shift', office = '$office', extension = $extension, state = '$state', experience = '$experience' where doctor_id = $doctor_id");
		try{

		$stmt->execute();

		echo "<script>alert('Doctor info updated');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('cannot update');  location.replace('admin.php'); </script>";
	}
	}

?>