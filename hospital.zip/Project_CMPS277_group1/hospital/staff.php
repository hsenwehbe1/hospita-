<!DOCTYPE html>
<html>
<head>
	<title>Staff</title>
	<link rel="stylesheet" type="text/css" href="css/staff.css">
</head>
<body>	

		<?php
				
				if(!isset($_GET['ssn'])){
						header('Location: login.php');
					}
					$ssn = $_GET['ssn'];

					require 'connect.php';
			    	$stmt = $conn->prepare("SELECT * FROM staff_details WHERE ssn = $ssn");
					$stmt->execute();
					$item = $stmt->fetch();

					$satff_id = $item['staff_id'];

					$stmt = $conn->prepare("SELECT h.holiday from holidays h, staff s where h.staff_id = s.staff_id AND s.staff_id = $satff_id;  ");
					$stmt->execute();
					$holidays = $stmt->fetchAll(PDO::FETCH_ASSOC);

					
						
			    ?>
			   
			    	
	  			<div class="container"> 
	  				<div class="div1">
	  					
	  					<p class="s">Staff Department</p>
	  			 	<p ><?php echo $item['lfirstname'].' '.$item['llastname'] ;?></p>
        		    
        		    
        			</div>
        			<br>
        			
        			<div class="div2">
        		    <p > Email: <?php echo $item['email'] ;?></p>
        		    <p > Study Degree: <?php echo $item['study_degree'] ;?></p>
        		    <p >Bank Account: <?php echo $item['bankaccount'] ;?></p>
        		    <p > Location: <?php echo $item['location'] ;?></p>
        		    <p >Type: <?php echo $item['type'] ;?></p>
        		    <p >Description: <?php echo $item['description'] ;?></p>
        		    <p > Salary: <?php echo $item['salary'] ;?> L.L</p>
        		    <p>Holidays:<br></p>

        		    <ul>
        		    
        		    <?php foreach ($holidays as $key => $value) {
        		    	
        		     ?>
        		    <li ><?php echo $value['holiday'] ;?></li>

        		<?php } ?>

        		</ul>

        		 	</div>
	  			</div>
			    		
		

</body>
</html>