<?php
	require 'connect.php';
	$reciever=explode("~",$_GET['q']);
	$a=$reciever[0];
	$b=$reciever[1];
	$c=$reciever[2];
	$d=$reciever[3];

	try{
		$insert=$conn->prepare("UPDATE hospital.appointment set appointment_date='$a' where patient_id='$c' and appointment_date='$b' and doctor_id='$d' ;");
		if($insert->execute()){
			echo "true";
		}else
		{
			echo "false";
		}
	}catch (PDOException $e){
		echo "false";
	}
?>