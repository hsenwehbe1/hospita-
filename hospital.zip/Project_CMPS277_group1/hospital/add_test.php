<?php

	require 'connect.php';

	if(isset($_POST['name'])){

		$name = $_POST['name'];

		$stmt = $conn->prepare("INSERT INTO test (id,name) values(null,'$name')");
		try{

		$stmt->execute();
			
		echo "<script>alert('Test Added');  location.replace('admin.php'); </script>";
	}
	catch(PDOException $e){
		echo "<script>alert('Test already exists'); location.replace('admin.php'); </script>";
	}
		
	}

?>