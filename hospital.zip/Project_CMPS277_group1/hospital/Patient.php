<!DOCTYPE html>
<html>
<head>
	
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script>
	var app="";
	var del_app="";
	function close_it(){
		$('#modal_1').css('display','none');
		$('#modal').css('display','none');
	}
	function update_col(appointment,pa,doctor){
		app=appointment+"~"+pa+"~"+doctor;
		console.log(app);
		$('#modal').css('display','block');
	}
	function delete_col(appointment,pa,doctor){
		del_app=appointment+"~"+pa+"~"+doctor;
		console.log(del_app);
		$('#modal_1').css('display','block');
	}
		$(document).ready(function(){
			$('#unique').click(function(){//when button is clicked
				if(!$('#up_date').val().length !== 0){//empty
					const ajax = new XMLHttpRequest();
					ajax.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							var resp = this.responseText;
							handleResponse(resp);
						}
					};
					var str=$('#up_date').val()+"~"+app;
					$('#up_date').val('');
					console.log(str);
					ajax.open("GET", "change_app.php?q="+str,true);
					ajax.send();
				}
			});
			$('#unique_1').click(function(){
				const ajax = new XMLHttpRequest();
				ajax.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						var resp = this.responseText;
						handleResponse(resp);
					}
				};
				$('#delete_it').val('');
				console.log(del_app);
				ajax.open("GET", "delete_it.php?q="+del_app,true);
				ajax.send();
			});
			function handleResponse(response){
				console.log(response);
				if(response==="true"){
					$('#display1').html("submit is changed,reload to update");
					$('#display2').html("submit is changed,reload to update");
				}else{
					$('#display1').html("coudn't change date");
					$('#display2').html("coudn't change date");
				}
			}
		});
	</script>
	<style>
	body{
		background: linear-gradient(to right,#D1CEE5,#A49ED1,#D1CEE5);
	}
		.container{
		margin-left:100px;
		display:flex;
		justify-content:space-between;
		width:90%;
	}
	.button {
		background-color: #4CAF50; /* Green */
		border: none;
		color: white;
		padding: 10px 15px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 10px;
		margin: 2px 1px;
		border-radius:15px;
		transition-duration: 0.4s;
		cursor: pointer;
	}
	
	
	.button2 {
		background-color: white; 
		color: black; 
		border: 1px solid #A49ED1;
	}

	.button2:hover {
		background-color: #9E98CE;
		color: white;
	}
	
	.child1{
		display:flex;
		flex-direction:column;
		border-radius: 20px;
		padding: 10px;
		border: 1px solid black;
		width:20%;
	}
	.child2{
		border-radius: 20px;
		padding: 10px;
		border: 1px solid black;
		display:flex;
		flex-direction:column;
		width:70%;
	}
	
	#modal {
		display: none; /* Hidden by default */
		position: fixed;/* Stay in place */
		z-index: 1; /* Sit on top */
		padding-top: 100px; /* Location of the box */
		left: 0;
		top: 0;
		width: 100%; /* Full width */
		height: 100%; /* Full height */
		overflow: auto; /* Enable scroll if needed */
		background-color: rgb(0,0,0); /* Fallback color */
		background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
	}
#data{
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  font-size: 14px;
  height: 100px;
  overflow-y: scroll;
}

#data td {
  border: 1px solid #ddd;
  padding: 8px;
}

#data tr:nth-child(even){background-color: #f2f2f2;}

#data tr:hover {background-color: #ddd;}

#data th {
  padding-top: 12px;
  padding-bottom: 12px;
  padding-left:10px;
  text-align: left;
  background-color: #7B67FC;
  color: white;
  
}
#data1{
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  font-size: 14px;
  height: 100px;
  overflow-y: scroll;
}

#data1 td {
  border: 1px solid #ddd;
  padding: 8px;
}

#data1 tr:nth-child(even){background-color: #f2f2f2;}

#data1 tr:hover {background-color: #ddd;}

#data1 th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7B67FC;
  color: white;
}
	/* Modal Content */
	.modal-content_1 {
	  background-color: #fefefe;
	  margin: auto;
	  border-radius:30px;
	  padding: 20px;
	  border: 1px solid #888;
	  width: 80%;
	}
	#modal_1 {
		display: none; /* Hidden by default */
		position: fixed;/* Stay in place */
		z-index: 1; /* Sit on top */
		padding-top: 100px; /* Location of the box */
		left: 0;
		top: 0;
		width: 100%; /* Full width */
		height: 100%; /* Full height */
		overflow: auto; /* Enable scroll if needed */
		background-color: rgb(0,0,0); /* Fallback color */
		background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
	}
	/* Modal Content */
	.modal-content {
	  background-color: #fefefe;
	  margin: auto;
	  border-radius:30px;
	  padding: 20px;
	  border: 1px solid #888;
	  width: 80%;
	}
	/* The Close Button */
	.close {
	  color: #aaaaaa;
	  float: right;
	  font-size: 28px;
	  font-weight: bold;
	}

	.close:hover,
	.close:focus {
	  color: #000;
	  text-decoration: none;
	  cursor: pointer;
	}
	.first_1{
		
	}
	h4,h2{
		color:#B0ACD6;
		font-family:Verdana, Geneva, sans-serif;
	}
	.pp{
		font-family:Verdana, Geneva, sans-serif;
	}
	p{
		color:#E9F4FB;
		font-family:Verdana, Geneva, sans-serif;
		
	}
	.child1 div{
		color:#8B84C4;
	}

	.child2 div{
		color:#8B84C4;
	}
	</style>
</head>
<body>
<?php
	require 'connect.php';
	$ssn=$_GET['ssn'];
	$pa =$conn->prepare("SELECT * from patient_details where ssn = $ssn");
	$pa->execute();
	$p=$pa->fetch(PDO::FETCH_ASSOC); 
	
	?>
	<div><h2>Patient info</h2></div><br>
	<div>
		<h4>patient </h4>
	</div>
	<div class="container" >
		<div style="background-color: white; 
		color: black; 
		border: 5px solid #A49ED1;" class="child1">
			<div >name : <?php echo $p['f'].' '.$p['l']?></div>
			<div >middle name :<?php echo $p['middle_name']?></div>
			<div >Hospital reg# :<?php echo $p['hospital_reg#']?> </div> 
			<div >tel number :<?php echo '+961 '.$p['phone_number']?></div>

			<?php

				$stmt = $conn->prepare("SELECT first_name, last_name from people p, doctor d where p.ssn = d.ssn AND d.ssn = (SELECT ssn from doctor_patient_details where doctor_patient_details.patient_id = ".$p['patient_id']." )");
				$stmt->execute();
				$doctor_patient = $stmt->fetch();

				if(isset($doctor_patient['first_name'])){
			?>
			<div>patient's doctor:<?php echo $doctor_patient['first_name'].' '.$doctor_patient['last_name']?></div>

		<?php }

		else { ?>

				<div>Add patient's doctor: 
					<form action="add_doctor_patient" method="post">
					<input type="hidden" name="patient_id" value="<?php echo $p['patient_id'] ?>" >
					<input type="hidden" name="ssn" value="<?php echo $ssn ?>" >
					<select style=" margin-top: 3%; color: #8B84C4;" name="doctor_id">

			<?php

			$stmt = $conn->prepare("SELECT d.doctor_id, p.first_name, p.last_name, d.state from doctor d, people p where p.ssn = d.ssn");
			$stmt->execute();
			$all_doctors = $stmt->fetchAll();

			foreach ($all_doctors as $key => $value) {

			?>

				<option <?php if($value['state'] != "available" ){ ?> disabled <?php }?>  value="<?php echo $value['doctor_id'] ?>" >
					<?php echo $value['first_name'].' '.$value['first_name'].' '.$value['state'] ?>
				</option>




		<?php
		}

		?>
		
		<input style="margin-top: 3%; border: 1px solid #8B84C4; background-color: white" type="submit"  value="Update" />
		</select>
	</form>
				</div>

<?php
	}
		$medic =$conn->prepare("SELECT * from patient_medications_details where ssn=$ssn;");
		$medic->execute();
		$medication=$medic->fetchAll(PDO::FETCH_ASSOC); 
		?>
		</div>
		
		<div style="background-color: white; 
		color: black; 
		border: 5px solid #A49ED1;" class="child2">
			<div>medication:</div>
		<?php foreach($medication as $m){?>
			<div>-medication name:<?php echo $m['name']?></div>
			<div>description :<?php echo $m['description']?></div>
			<?php
			}
		?>
		</div>
	</div>
	<?php ?>
	<div>
		<h4>appointment</h4>
	</div>
	<?php 
		$app=$conn->prepare("SELECT * from patient_appointments_details where ssn = $ssn");
		$app->execute();
		$appointment=$app->fetchAll(PDO::FETCH_ASSOC);
		$i=1;
	?>
		<table id="data">
			<tr>
				<th><p>appointment day</p></th>
				<th><p>type</p></th> 
				<th><p>doctor name</p></th>
				<th><p>doctor extension number</p></th>
				<th><p>doctor office</p></th>
				<th><p>update/delete</p></th>	
			</tr>
			<?php foreach($appointment as $a){?>
			<tr class="<?php echo $a['appointment_date'].'_'.$i?>" >
				<td><?php echo $a['appointment_date'] ?></td>
				<td><?php echo $a['type'] ?></td>
				<td><?php echo $a['first_name'].' '.$a['last_name'] ?></td>
				<td><?php echo $a['extension'] ?></td>
				<td><?php echo $a['office'] ?></td>
				<td><button class="button button2" onclick="update_col('<?php echo $a['appointment_date']?>','<?php echo $a['patient_id']?>','<?php echo $a['doctor_id']?>')">edit</button> <button class="button button2" onclick="delete_col('<?php echo $a['appointment_date']?>','<?php echo $a['patient_id']?>','<?php echo $a['doctor_id']?>')">delete</button></td>
			</tr>
			<?php
			$i++;
				}
			?>
		</table>
		<div id="modal" >
			<div class="modal-content">
				<span class="close" onclick="close_it();">&times;</span>
				<label for="up">reschedule appointment's date</label>
				<input type="datetime-local" style="border-radius:20px; border:1px solid #A49ED1;" name="up" id="up_date"/>
				<button id="unique" type="button" class="button button2">submit change</button>
				<div id="display1">
				</div>
			</div>
		</div>
		<div id="modal_1" >
			<div class="modal-content_1">
				<span class="close" onclick="close_it();">&times;</span>
				<span class="pp">are you sure you want to delete?</span>
				<button id="unique_1" type="button" class="button button2">yes</button>
				<div id="display2">
				</div>
			</div>
		</div>
	<div>
		<h4>tests</h4>
	</div>
	<?php
		$testd=$conn->prepare("SELECT * from patient_test_details where ssn= $ssn;");
		$testd->execute();     
		$test_done=$testd->fetchAll(PDO::FETCH_ASSOC); 
	?>
	<table id="data1">
		<tr>
			<th>test name</th>
			<th>doctor </th> 
			<th>test done date </th>
			<th>test result date</th>
		</tr>
		<?php
			foreach($test_done as $t){
		?>
		<tr>
			<td><?php echo $t['name'] ?></td>
			<td><?php echo $t['drfn'].' '.$t['drln'] ?></td>
			<td><?php echo $t['date_done'] ?></td>
			<td><?php echo $t['result_date'] ?></td>
		</tr>
		<?php
			}
		?>
	</table>
	</body>
</html>