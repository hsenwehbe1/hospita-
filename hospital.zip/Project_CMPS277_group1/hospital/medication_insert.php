<?php
	require 'connect.php';
	$reciever=explode("~",$_GET['q']);
	$a=$reciever[0];
	$b=$reciever[1];
	$c=$reciever[2];
	try{
	
		$query="INSERT into medication_taken value('$a','$b','$c');";
	
		$stmt = $conn->prepare($query);
		

		if($stmt->execute()){
			echo "true";
		}else
		{
			echo "false";
		}
	}catch (PDOException $e){

		echo "false";
	}
	?>
	
	
	
	