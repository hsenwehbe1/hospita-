<?php

	require 'connect.php';

	if(isset($_POST['name']) && isset($_POST['description']) && isset($_POST['med_id']) ){

		$name = $_POST['name'];
		$description = $_POST['description']; 
		$id = $_POST['med_id'];

		$stmt = $conn->prepare("UPDATE medications SET name = '$name', description = '$description' where id = $id");
		try{

		$stmt->execute();

		echo "<script>alert('Medication Updated');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('Medication is not Updated');  location.replace('admin.php'); </script>";
	}
	}

?>