<?php

	require 'connect.php';

	if(isset($_POST['name']) && isset($_POST['test_id']) ){

		$name = $_POST['name']; 
		$id = $_POST['test_id'];

		$stmt = $conn->prepare("UPDATE test SET name = '$name' where id = $id");
		try{

		$stmt->execute();

		echo "<script>alert('Test info updated');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('cannot update');  location.replace('admin.php'); </script>";
	}
	}

?>