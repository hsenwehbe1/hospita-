<!DOCTYPE html>
<html>
<head>
	<title>Log in</title>
	<link rel="stylesheet" type="text/css" href="css/login.css">
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
</head>
<body>
 <div class="content">
 	<div class="div1">

				<?php
				
					require 'connect.php';
			    	$stmt = $conn->prepare("SELECT * FROM hospital;");
					$stmt->execute();
					$item = $stmt->fetch();
					$reg = $item['Registrationnumber'];
			    ?>
			   
			    	
	  			<div class="container"> 
					<p > Hospital Name: <?php echo $item['name'] ;?></p>
        		    <p >Manager: <?php echo $item['manager'] ;?></p>
        		    <p >Location: <?php echo $item['location'] ;?></p>
         		    <p >Registration Number: <?php echo $item['Registrationnumber'] ;?></p>
         		    <p >Phone Number: <?php echo $item['phonenumber'] ;?></p>
        
					
	  			</div>

			    <div style="margin-left: 4%; margin-top: 3%; align-self: flex-start; color: white; font-weight: lighter;" >
			    	Blood Units found:
			    	<ul>
			    		<?php 

			    		$stmt = $conn->prepare("SELECT * from bloodunit where hospId = $reg; ");
			    		$stmt->execute();
			    		$units = $stmt->fetchAll();

			    		foreach ($units as $key => $value) {
			    
			    		?>
			    			<li><?= $value['amount'] ?> units of type <?= $value['type'] ?></li>

			    	<?php } ?>
			    	</ul>
			    </div>
			   	<img src="images/hospital.png"> 
</div>
			 <div style="display: flex; flex-direction: row; background-color: #F5F5F5; " class="maindiv" >
			    <br>
			    <div style="width: 50%;" class="div2">
			    <label>Choose your name: </label>
			    <br>
			    <br>
			    <select id="login" name="login" multiple style="width: 250px ;height: 200px">
			    	
			    <?php
				
					require 'connect.php';
			    	$stmt = $conn->prepare("SELECT ssn,type,first_name,last_name,phone_number FROM people ORDER BY first_name , last_name;");
					$stmt->execute();
					$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
			
					foreach ($items as $row => $item) {

						
						
			    ?>
			  
 							 <option onclick="saveSSN('<?php echo $item['ssn'].' '.$item['type'];?>');" value="<?php echo $item['first_name'].' '.$item['last_name'].' '.$item['phone_number'] ;?>"><?php echo $item['first_name'].' '.$item['last_name'].' '.$item['phone_number'] ;?></option>
  
				
	  			
			    		
			    		<?php
			    		
			    	}
			    		?>
			    		</select><br>
<br>
		<input  class="button" type="button" value="Log in" onclick="ar = user.split(' ');
 		window.location = ar[1]+'.php?ssn='+ar[0];" />
		<a class="button" href="admin.php">Login as admin</a>
</div>

<div id="searchDiv" style="width: 40%;" >
	<br>
 	
 	<label  >Search By:</label>
 	<select id="search_type" >
 		<option value="first_name" >First Name</option>
 		<option value="middle_name" >Middle Name</option>
 		<option value="last_name" >Last Name</option>
 		<option value="dep_name" >Department</option>
 		<option value="gender" >Gender</option>
 	</select>

 	<br>
 	<br>
 	<label  style="min-width: 170px; display: inline-block;">Search Query:</label>
 	<input id="query" type="text" name="query">
 	<br><br>
 	<label style="min-width: 70px; display: inline-block;">Results:</label>
 	 <select id="search_result" name="search_result" multiple style=" vertical-align: top; width: 250px ;height: 200px">
 	 	
 	 </select>

 	 <br><br>

 	 	<input style="float: right;"  class="button" type="button" value="Search" onclick="getResults()" />

 </div>
 </div>
 </div>

 

 <script type="text/javascript">

 	user = "";
 	

 	function saveSSN(input){
 		user = input;

 	}

 	function getResults(){

 		var query = $('#query').val();
 		var search_type = $('#search_type').val();


 		$.ajax({
	        url: 'getResults.php',
	        method: 'get',
	        data: {'search_type': search_type, 'query': query},
	        dataType: 'json',
	        success: function (response) {
	        	if(response.error){
	        		alert(response.message);
	        	}
	        	else
	        	{

	        		$('#search_result').empty();
					var items = response.message;

				if(items.length == 0){

				$('<option disabled>No search Results</option>').prependTo($('#search_result'));	  
				}

				else{
            	
            	jQuery.each( items, function( i, val ) {
 	
 				$('<option onclick="saveSSN(\''+val.ssn+' '+val.type+'\');" value="'+val.first_name+' '+val.last_name+'">'+val.first_name+' '+val.last_name+' '+val.dep_name+' </option>').prependTo($('#search_result'));	        

		
					});
            }
	        	}
	        }

	    });

 	}

 </script>

</body>
</html>





