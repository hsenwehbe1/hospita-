<?php

	require 'connect.php';

	if(isset($_POST['fname']) && isset($_POST['mname']) && isset($_POST['lname']) && isset($_POST['phone']) && isset($_POST['gender']) && isset($_POST['people_ssn'])){

		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];

		$phone = $_POST['phone'];
		$gender = $_POST['gender'];

		$ssn = $_POST['people_ssn'];


		$stmt = $conn->prepare("UPDATE people SET first_name = '$fname', middle_name = '$mname', last_name = '$lname', phone_number = $phone, gender = '$gender' where ssn = $ssn");
		try{

		$stmt->execute();

		echo "<script>alert('Person info updated');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('cannot update');  location.replace('admin.php'); </script>";
	}
	}

?>