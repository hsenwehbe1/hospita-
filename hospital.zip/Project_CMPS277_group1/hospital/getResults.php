<?php

	require 'connect.php';

	if(isset($_GET['search_type']) && isset($_GET['query'])){

		$search_type = $_GET['search_type'];
		$query = $_GET['query'];
	


		$stmt = $conn->prepare("SELECT ssn, first_name, last_name, dep_name, type FROM people 
			WHERE $search_type LIKE '$query%'");
		$stmt->execute();

		$items = $stmt->fetchAll();

		$result['error'] = false;
		$result['message']  = $items;
	}

	else{

		$result['error'] = true;
		$result['message']  = "Missing fields";
	}


	echo json_encode($result);
?>