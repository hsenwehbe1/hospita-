


<!DOCTYPE html>
<html>
<head>
	<title>Nurse</title>
	<link rel="stylesheet" type="text/css" href="css/nurse.css">
</head>
<body>
	



		<?php
					if(!isset($_GET['ssn'])){
						header('Location: login.php');
					}
					$ssn = $_GET['ssn'];
					require 'connect.php';
			    	$stmt = $conn->prepare("SELECT * FROM nurse_details WHERE ssn = $ssn");
					$stmt->execute();
					$item = $stmt->fetch();


					$nurse_id = $item['nurse_id'];

					$stmt = $conn->prepare("SELECT * FROM supervisor_details where nurse_id = $nurse_id");

					$stmt->execute();

					$supervisor = $stmt->fetch();

						
			    ?>
			   
			    	
	  			<div class="container"> 
	  				<div class="div1">
	  					
	  					<p class="s"><?php echo $item['department'] ;?> Department</p>
	  			 	<p style="text-align: center;font-size: 23px;"> Nurse:<?php echo $item['lfirstname'].' '.$item['llastname'] ;?></p>
        		    
        		    
        			</div>
        			<br>
        			
        			<div class="div2">
        		    <p > Email: <?php echo $item['email'] ;?></p>
        		    <p > Phone Number: <?php echo $item['phonenumber'] ;?></p>
        		    <p > Gender: <?php echo $item['gender'] ;?></p>
        		    <p > Study Degree: <?php echo $item['study_degree'] ;?></p>
        		    <p >Bank Account: <?php echo $item['bankaccount'] ;?></p>
        		    <p > Location: <?php echo $item['location'] ;?></p>
        		    <p > Floor: <?php echo $item['floor'] ;?></p>
        		     <p > Shifts: <?php echo $item['shifts'] ;?></p>

        		     <?php if(isset($supervisor['first_name'])){ ?>

        		     	<p>Supervisor: <?php echo $supervisor['first_name'].' '.$supervisor['last_name']; ?> </p>

        		     <?php } else{ ?>

        		     	<p>Supervisor: You are a supervisor </p>

        		     <?php } ?>

        		   
        		   
        		   

        		 	</div>
	  			</div>
			    		
			   

</body>
</html>
