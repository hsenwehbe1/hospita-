<?php

	require 'connect.php';

	if(isset($_POST['supervisor']) && isset($_POST['shifts']) && isset($_POST['floor']) && isset($_POST['nurse_id'])){

		$supervisor = $_POST['supervisor'];
		$shifts = $_POST['shifts'];
		$floor = $_POST['floor'];
		$nurse_id = $_POST['nurse_id'];


		$stmt = $conn->prepare("UPDATE nurse SET shifts = '$shifts', floor = $floor, supervisor_id = $supervisor where nurse_id = $nurse_id");
		try{

		$stmt->execute();

		echo "<script>alert('Nurse info updated');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('cannot update');  location.replace('admin.php'); </script>";
	}
	}

?>