<?php

	require 'connect.php';

	if(isset($_POST['first_name']) && isset($_POST['middle_name']) && isset($_POST['last_name']) && isset($_POST['phone']) && isset($_POST['gender']) && isset($_POST['main_type']) && isset($_POST['dep_name'])){

		$fname = $_POST['first_name'];
		$mname = $_POST['middle_name'];
		$lname = $_POST['last_name'];

		$phone = $_POST['phone'];
		$gender = $_POST['gender'];
		$department = $_POST['dep_name'];

		$main_type = $_POST['main_type'];

		$t = ucfirst($main_type);


		$sql = "INSERT INTO people VALUES(NULL,DEFAULT,$phone, '$fname', '$mname', '$lname', '$gender', '$department', '$t')";

		if($main_type == "patient"){

			if(isset($_POST['case_type']) && isset($_POST['medical_record']) && isset($_POST['room'])){

				$case_type = $_POST['case_type'];
				$medical_record = $_POST['medical_record'];
				$room = $_POST['room'];

				$stmt = $conn->prepare($sql);
				$stmt->execute();

				$ssn = $conn->lastInsertId();

				$stmt = $conn->prepare("INSERT INTO patient VALUES(NULL, $ssn, '$case_type', '$medical_record', $room) ");
				$stmt->execute();


				$stmt = $conn->prepare("SELECT number_of_beds, state,extension from room where extension = $room");

				$stmt->execute();
				$new_room_data = $stmt->fetch();


				if($new_room_data['state'] == 'empty' && $new_room_data['number_of_beds'] == 2){
					$s = 'not full';
				}

				else if($new_room_data['state'] == 'empty' && $new_room_data['number_of_beds'] == 1){
					$s = 'full';
				}

				else if($new_room_data['state'] == 'not full'){
					$s = 'full';
				}

				$stmt = $conn->prepare("UPDATE room set state = '$s' where extension = $room");
				$stmt->execute();

				echo "<script>alert('Patient inserted successfully'); window.location = 'admin.php';</script>";


		}

		else{
			echo "Patient Fields are missing";
		}
	}

	else if ($main_type == "employee") {

		if(isset($_POST['sec_type']) && isset($_POST['bank_account']) && isset($_POST['location']) && isset($_POST['email']) && isset($_POST['study_degree'])  ){
	
			$sec_type = $_POST['sec_type'];
			$study_degree = $_POST['study_degree'];
			$bank_account = $_POST['bank_account'];
			$location = $_POST['location'];
			$email = $_POST['email'];

			$t = ucfirst($sec_type);


			$sql = "INSERT INTO people VALUES(NULL,DEFAULT,$phone, '$fname', '$mname', '$lname', '$gender', '$department', '$t')";

			$stmt = $conn->prepare($sql);
			$stmt->execute();

			$ssn = $conn->lastInsertId();

			$sqlEmployee = "INSERT INTO employee VALUES(NULL,$ssn, '$bank_account', '$location', '$email', '$study_degree')";


			if($sec_type == "doctor"){

				if(isset($_POST['shift']) && isset($_POST['office']) && isset($_POST['extension']) && isset($_POST['experience']) && isset($_POST['state'])){

					$shift = $_POST['shift'];
					$office = $_POST['office'];
					$extension = $_POST['extension'];
					$experience = $_POST['experience'];
					$state = $_POST['state'];

					$stmt = $conn->prepare($sqlEmployee);
					$stmt->execute();

					$hospital_id = $conn->lastInsertId();

					$stmt = $conn->prepare("INSERT INTO doctor VALUES(NULL,$ssn, $hospital_id, '$office', $extension, '$shift', '$state', '$experience')");
					$stmt->execute();


					echo "<script>alert('Doctor inserted successfully'); window.location = 'admin.php';</script>";


				}

				else{
					echo "Doctor fields are missing";
				}

			}

			else if($sec_type == "nurse"){

				if(isset($_POST['shifts']) && isset($_POST['floor']) && isset($_POST['supervisor'])){

					$shifts = $_POST['shifts'];
					$floor = $_POST['floor'];
					$supervisor = $_POST['supervisor'];

					$stmt = $conn->prepare($sqlEmployee);
					$stmt->execute();

					$hospital_id = $conn->lastInsertId();

					$stmt = $conn->prepare("INSERT INTO nurse VALUES(NULL,$hospital_id, $ssn, '$shifts', $floor, $supervisor)");
					$stmt->execute();


					echo "<script>alert('Nurse inserted successfully'); window.location = 'admin.php';</script>";

				}

				else{
					echo "Nurse fields are missing";
				}

			}

			else if($sec_type == "staff"){

				if(isset($_POST['salary']) && isset($_POST['description']) && isset($_POST['staff_type'])){

					$salary = $_POST['salary'];
					$description = $_POST['description'];
					$staff_type = $_POST['staff_type'];

					$stmt = $conn->prepare($sqlEmployee);
					$stmt->execute();

					$hospital_id = $conn->lastInsertId();

					$stmt = $conn->prepare("INSERT INTO staff VALUES(NULL,$ssn, $hospital_id, '$staff_type', $salary, '$description')");
					$stmt->execute();


					echo "<script>alert('Staff inserted successfully'); window.location = 'admin.php';</script>";

				}

				else{
					echo "Staff fields are missing";
				}

			}

			else{
				echo "Wrong sec_type";
			}

		}

		else{
			echo "Employee fields are missing";
		}

	}


}

	else{
		echo "fields are missing";
	}


?>