<?php

	require 'connect.php';

	if(isset($_POST['salary']) && isset($_POST['type']) && isset($_POST['staff_id']) && isset($_POST['description'])){

		$salary = $_POST['salary'];
		$type = $_POST['type'];
		$staff_id = $_POST['staff_id'];
		$description = $_POST['description'];


		$stmt = $conn->prepare("UPDATE staff SET salary = $salary, type = '$type', description = '$description' where staff_id = $staff_id");
		try{

		$stmt->execute();

		echo "<script>alert('Staff info updated');  location.replace('admin.php'); </script>";


	}
	catch(PDOException $e){
		echo "<script>alert('cannot update');  location.replace('admin.php'); </script>";
	}
	}

?>